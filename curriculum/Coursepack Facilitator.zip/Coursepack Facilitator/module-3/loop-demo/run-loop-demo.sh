#!/usr/bin/env bash
# Module 3 I Do, Demo C: compile and run both versions of the sum loop.
# Usage (from any folder):  bash ~/coursepack/facilitator/module-3/loop-demo/run-loop-demo.sh
HERE="$(cd "$(dirname "$0")" && pwd)"
WORK="$(mktemp -d)"
if ! cobc -x -std=ibm -o "$WORK/loopdemo" "$HERE/LOOPDEMO.cbl" 2> "$WORK/cobc.log"; then
    cat "$WORK/cobc.log"; rm -rf "$WORK"; exit 1
fi
"$WORK/loopdemo"
rm -rf "$WORK"
