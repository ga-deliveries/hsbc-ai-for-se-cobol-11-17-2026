       IDENTIFICATION DIVISION.
       PROGRAM-ID. LOOPDEMO.
      *================================================================*
      * MODULE 3 I DO, DEMO C. RUNS THE BEFORE AND AFTER VERSIONS OF   *
      * THE SUM LOOP ON THE SAME TABLE (10, 20, 30) FOR WS-COUNT 0-3.  *
      * FACILITATOR ONLY. RUN WITH run-loop-demo.sh                    *
      *================================================================*
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-COUNT            PIC 9(03).
       01  WS-IDX              PIC 9(03).
       01  WS-TOTAL            PIC 9(05).
       01  WS-TABLE.
           05  WS-AMT          PIC 9(03) OCCURS 5 TIMES.
       01  WS-N                PIC 9(01).
       01  WS-USED             PIC X(12).
       01  WS-USED-PTR         PIC 9(02).
       01  WS-BEFORE-TOTAL     PIC 9(05).
       01  WS-BEFORE-USED      PIC X(12).
       01  WS-RESULT           PIC X(09).
       01  WS-SHOW-COUNT       PIC 9.
       01  WS-SHOW-IDX         PIC 9.
       01  WS-SHOW-TOTAL       PIC Z9.
       01  WS-SHOW-BTOTAL      PIC Z9.

       PROCEDURE DIVISION.
       0000-MAIN.
           MOVE 10 TO WS-AMT (1)
           MOVE 20 TO WS-AMT (2)
           MOVE 30 TO WS-AMT (3)
           MOVE ZERO TO WS-AMT (4) WS-AMT (5)
           DISPLAY 'Table: WS-AMT (1) = 10, (2) = 20, (3) = 30'
           DISPLAY ' '
           DISPLAY 'WS-COUNT | BEFORE: items   total | '
                   'AFTER: items    total | Result'
           DISPLAY '---------+-----------------------+'
                   '-----------------------+----------'
           PERFORM VARYING WS-N FROM 0 BY 1 UNTIL WS-N > 3
               MOVE WS-N TO WS-COUNT
               PERFORM 1000-RUN-BEFORE
               PERFORM 2000-RUN-AFTER
               PERFORM 3000-SHOW-ROW
           END-PERFORM
           STOP RUN.

       1000-RUN-BEFORE.
           MOVE ZERO TO WS-TOTAL
           MOVE SPACES TO WS-USED
           MOVE 1 TO WS-USED-PTR
           PERFORM 4000-BEFORE-LOOP THRU 4000-EXIT
           MOVE WS-TOTAL TO WS-BEFORE-TOTAL
           MOVE WS-USED TO WS-BEFORE-USED.

      * BEFORE: THE ORIGINAL GO TO LOOP, EXACTLY AS IN THE DEMO
       4000-BEFORE-LOOP.
           MOVE 1 TO WS-IDX.
       4000-SUM-LOOP.
           IF WS-IDX > WS-COUNT
               GO TO 4000-EXIT
           END-IF
           ADD WS-AMT (WS-IDX) TO WS-TOTAL
           PERFORM 5000-NOTE-ITEM
           ADD 1 TO WS-IDX
           GO TO 4000-SUM-LOOP.
       4000-EXIT.
           EXIT.

      * AFTER: THE REFACTORED LOOP, EXACTLY AS IN THE DEMO
       2000-RUN-AFTER.
           MOVE ZERO TO WS-TOTAL
           MOVE SPACES TO WS-USED
           MOVE 1 TO WS-USED-PTR
           PERFORM WITH TEST AFTER
               VARYING WS-IDX FROM 1 BY 1
               UNTIL WS-IDX >= WS-COUNT
               ADD WS-AMT (WS-IDX) TO WS-TOTAL
               PERFORM 5000-NOTE-ITEM
           END-PERFORM.

       3000-SHOW-ROW.
           IF WS-TOTAL = WS-BEFORE-TOTAL
               MOVE 'SAME' TO WS-RESULT
           ELSE
               MOVE 'DIFFERENT' TO WS-RESULT
           END-IF
           MOVE WS-COUNT TO WS-SHOW-COUNT
           MOVE WS-BEFORE-TOTAL TO WS-SHOW-BTOTAL
           MOVE WS-TOTAL TO WS-SHOW-TOTAL
           IF WS-BEFORE-USED = SPACES
               MOVE 'none' TO WS-BEFORE-USED
           END-IF
           DISPLAY '    ' WS-SHOW-COUNT '    | '
                   WS-BEFORE-USED '   ' WS-SHOW-BTOTAL '    | '
                   WS-USED '  ' WS-SHOW-TOTAL '    | ' WS-RESULT.

       5000-NOTE-ITEM.
           MOVE WS-IDX TO WS-SHOW-IDX
           STRING WS-SHOW-IDX ' ' DELIMITED BY SIZE
               INTO WS-USED WITH POINTER WS-USED-PTR
           END-STRING.
