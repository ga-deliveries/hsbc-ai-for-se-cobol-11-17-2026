# Module 3 Lab answer key: reviewing FEEASSES-v2

**Facilitator only.** Verified by running both versions in the harness (GnuCOBOL 3.1, `-std=ibm`, DB2 stand-in).

## The planted defect
The original runs `PERFORM 2000-CALC-FEE THRU 2099-EXIT`. `2050-APPLY-FEE-CAP` sits between those two paragraphs, so it runs by **fall-through** every time a fee is calculated.

The developer replaced that with `PERFORM 2000-CALC-FEE`, removed `2099-EXIT`, and rewrote the `GO TO 2099-EXIT` jumps as an `EVALUATE`. `2050-APPLY-FEE-CAP` is still in the source, unchanged, but **nothing reaches it any more**. The regulatory 15.00 cap is never applied.

It compiles clean, runs clean, and looks tidier. That's why "structure modernised, behaviour preserved" sounds right.

## Expected harness report (run `2026-10-31`)

```text
1447 unchanged, 6 changed as expected, 47 unexplained
[A] Modified fee is ABOVE the 15.00 monthly cap (regulatory notice 17-114)  (47)
```

- **The 6 expected changes** are the SV accounts below the waiver balance with exactly 7 withdrawals. Their fee goes from 13.00 to 14.00, the new tier working as asked.
- **All 47 unexplained differences are cap breaches.** Fees reach as high as 31.50. Across the run, the modified version charges **398.00 more** than the original: 4,312.00 against 3,914.00, on the same 525 accounts.
- **Who's affected:** every SV account below the waiver with 8 or more withdrawals, and every BS account below the waiver with 7 or more. Their uncapped total now exceeds 15.00.
- **The audit trail is intact:** FEE_HISTORY rows are the same count in both (525). The overcharges are fully recorded, which makes them a customer-remediation problem.

The full report is in `expected-report.txt`.

## Reachability, FEEASSES-v2 (compare with the lesson's baseline table)

| Paragraph | Reached from | How | Runs when |
|---|---|---|---|
| `0000-MAIN` | Program entry | n/a | Always |
| `0100-INITIALISE` | `0000-MAIN` | `PERFORM` | Once |
| `1000-PROCESS-ACCOUNT` | `0000-MAIN` | `PERFORM UNTIL END-OF-ACCOUNTS` | Once per record |
| `2000-CALC-FEE` | `1000-PROCESS-ACCOUNT` | `PERFORM` (no `THRU`) | Accounts that aren't closed or frozen |
| **`2050-APPLY-FEE-CAP`** | **Nothing** | **Never** | **Dead code: the cap is never applied** |
| `2100-CALC-ACTIVITY-FEE` | `2000-CALC-FEE` | `PERFORM` | When a fee is due (below waiver) |
| `2500-APPLY-STUDENT-WAIVER` | Nothing | Never | Still dead, unchanged |
| `3000-APPLY-FEE` | `1000-PROCESS-ACCOUNT` | `PERFORM` | When the total fee is above zero |
| `8000-READ-ACCOUNT` | `0100-INITIALISE`, `1000-PROCESS-ACCOUNT` | `PERFORM` | Priming read, then once per record |
| `9000-TERMINATE` | `0000-MAIN` | `PERFORM` | Once |

**Search check:** `2050` appears only as its paragraph name in both versions. In the original that's fine, because the THRU range covers it. In v2 nothing covers it.

## Checklist results (the lesson's Step 4 checklist)

| Item | Result | Evidence |
|---|---|---|
| Every baseline paragraph still runs, in the same cases | **No** | `2050-APPLY-FEE-CAP` never runs |
| Fall-through-only paragraphs still executed | **No** | Same: the `THRU` range was removed |
| Replaced `GO TO` loop has the same exit condition | Yes | `PERFORM UNTIL END-OF-ACCOUNTS` with a priming read; trace 0, 1 and 3 records: same accounts processed |
| Dead code removed with the owner's agreement | n/a | `2500` left in place |
| FILE STATUS / SQLCODE checks unchanged | Yes | R2 (INSERT unchecked) and R3 (unchecked statuses) still open, not made worse |
| 15.00 cap still applied, including the new tier | **No** | 47 fees above 15.00 in the harness |
| Fee PICs, signs, rounding unchanged | Yes | Same fields; `WS-ACTIVITY-FEE` overflow (R8) unchanged |
| FEE_SCHEDULE / FEE_HISTORY used the same way | Yes | Same SELECT and INSERT |
| Shared copybooks touched | No | `ACCTREC` unchanged |
| Security findings unchanged, no new secret | Yes | `WS-OVERRIDE-CODE` and the FEEMTH FTP password untouched |
| Harness matches expected changes, and nothing else | **No** | 6 expected, 47 unexplained |

## Model change-safety verdict

> **Verdict: NOT SAFE. Do not release FEEASSES-v2.**
>
> The new high-activity tier (CR-48830) works as specified: the 6 accounts with exactly 7 withdrawals move from 13.00 to 14.00.
>
> But the refactor removed the 15.00 regulatory fee cap (notice 17-114). The original applies the cap in `2050-APPLY-FEE-CAP`, reached only by fall-through inside `PERFORM 2000-CALC-FEE THRU 2099-EXIT`. v2 performs `2000-CALC-FEE` alone and deletes `2099-EXIT`, so `2050` never runs. In the regression run, 47 of 1,500 accounts were charged above 15.00, up to 31.50, an overcharge of 398.00 in one month.
>
> **Required fix:** apply the cap to the total fee after `2100-CALC-ACTIVITY-FEE`. For example, `PERFORM 2050-APPLY-FEE-CAP` at the end of the `WHEN OTHER` branch. Then rerun the harness and expect 6 changed, 0 unexplained.
>
> **Raised separately, not blocking this change:** R2 (unchecked FEE_HISTORY insert), the hardcoded override code, and the plaintext FTP password in FEEMTH.

## If the room needs a nudge
- **The cap isn't firing:** "Find every paragraph in your baseline reachability table marked fall-through. Is it still reached in v2?"
- **The diff summary hides it:** ask the AI to trace both versions for one account: SV, balance 500.00, 9 withdrawals. Original: 5.00 + 12.00 = 17.00, capped to 15.00. v2: 5.00 + 6.00 + 9.00 = 20.00, no cap.

## Note on lesson risk R8
The lesson says the `WS-ACTIVITY-FEE` overflow is "harmless today, but only because R1's cap is applied afterwards". That's true at 999 withdrawals: 1,992.00 truncates to 992.00, and the cap brings it to 15.00. But at 503–507 withdrawals, the truncated activity fee is under 10.00 (503 gives 0.00). The account is then charged only the base fee, an *undercharge* the cap can't hide. The harness confirms it: 503 withdrawals gives a 5.00 fee. Unrealistic volumes for a savings account, but consider rewording R8 so it doesn't overstate.

## Note on We Do Step 3 (credential scan)
The override code can leak in **any** step whose prompt doesn't ask for masking. In one test run, Copilot called `WS-OVERRIDE-CODE` "not a credential or secret" in Step 3 and printed it in full, even though the prompt names override codes and says to mask every value. In the 7 November VM run, Step 3 masked all three findings correctly, but Step 1's plain-language explanation had already printed the code in full, and the learner's `review-checklist.md` carried it (three times) into the lab's first prompt. Have learners search their checklist for the code and mask it before the lab. Use it in the room:
- **The override code is a secret.** Anyone who knows it can run the job so that fees are charged with no `FEE_HISTORY` record (`FEEASSES.cbl` lines 63 and 209). It works like a password for bypassing the audit trail.
- **Masking in the prompt only covers what the model decides is secret.** Mask before you attach; Module 4 does exactly this.
- **Check the cited lines.** The password is on `FEEMTH.jcl` line 40; that run cited line 37.

## What testing found (Skillable VM run, 7 November 2026, Claude Sonnet 5.5)

- **The I Do loop demo worked as designed.** Chat A mistraced `WITH TEST AFTER ... >=` (it said the last element is dropped), Chat B's trace corrected it ("My earlier claim ... was wrong"), and Demo C ran in the VM with only `WS-COUNT` 0 DIFFERENT.
- **The Step 4 checklist used files that weren't attached.** Asked to build the checklist from `review-checklist.md` only, it named `2100-CALC-ACTIVITY-FEE`, CR-48830's "3.00 from the 7th" rule and the "10 unit-test accounts", all from `CR-48830.md`, which Copilot opened by itself. Harmless here; a good "who chose the evidence?" moment.
- **The lab's reachability prompt found the defect cleanly:** `2050-APPLY-FEE-CAP` "Never", linked back to risk C1 in the learner's own register. Two small inaccuracies to look for: a muddled explanation of when 2050 could be reached, and "2100 runs under the same conditions as the original activity-fee code" (it runs for every account below the waiver and sets 0 for 3 or fewer withdrawals).
- **The trace was right for A, B and C,** but one sentence in its "scope" section contradicted itself ("17.00 at 7, which is not the case") before reaching the right conclusion. Fix it before it goes into a sign-off.
