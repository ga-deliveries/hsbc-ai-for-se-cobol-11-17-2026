# scenarios.md: Module 2 answer key

**Facilitator only.** Every expected value below was confirmed by running the original and modified INTCALC in the harness.

## Expected-change rule

In a daily run, an account should produce different output when it is not closed, frozen (including legal hold) or dormant, and its balance is 10,000.00 or more. Everything else should be identical.

At month-end, rounding to the cent can absorb the difference, so "should change" means "may change". S05 capitalises to 10,000.62 in both versions.

## Boundary scenarios for the rate change

Runs: D = `20261030,N`, M = `20261031,Y`, L = `20280229,N`. Values are the daily interest added to `ACCT-ACCRUED-INT`, unless the row says otherwise. All accounts are type `SV`, status `A`, unless noted.

| ID | Input | Expected: original | Expected: modified | Should change? | Harness result | Why it matters |
|---|---|---|---|---|---|---|
| S01 | Balance 0.00, run D | No accrual | No accrual | No | Verified | Zero balance is excluded by the `EVALUATE` |
| S02 | Balance -0.01, run D | No accrual | No accrual | No | Verified | Overdrawn accounts earn nothing; tests the `D` sign half-byte |
| S03 | Balance 1,000.00, run D | 0.0342 | 0.0342 | No | Verified | Exactly on the tier 2 floor, so 1.25% applies |
| S04 | Balance 999.99, run D | 0.0136 | 0.0136 | No | Verified | One cent below tier 2, so 0.50% applies |
| S05 | Balance 10,000.00, run D | 0.6219 | 0.6232 | **Yes** | Verified | Exactly on the tier 3 floor |
| S06 | Balance 9,999.99, run D | 0.3424 | 0.3424 | No | Verified | One cent below tier 3 must stay on tier 2 |
| S07 | Balance 50,000.00, run D | 4.2739 | 4.2808 | **Yes** | Verified | Exactly on the tier 4 floor |
| S08 | Type `BS`, bonus `Y`, 0 withdrawals, 20,000.00, run D | 1.5178 | 1.5205 | **Yes** | Verified | Tier 3 plus the 0.500 bonus |
| S09 | Status `D`, balance 20,000.00, run D | 0.2739 | 0.2739 | No | Verified | Dormant stays on tier 1 |
| S10 | The S03 record, run L | 0.0341 | 0.0341 | No | Verified | Leap year divides by 366 |
| S11 | Balance 100.00, accrued 0.0037, run M | Balance 100.01, accrued 0 | Same | No | Verified | Accrued reaches 0.0050 and rounds up |
| S12 | Balance 100.00, accrued 0.0036, run M | Balance 100.00, accrued 0 | Same | No | Verified | Accrued reaches 0.0049 and rounds down |
| S13 | Balance 9,999,999.99, run M | Overflow; balance unchanged, accrued reset to 0 | Same | No | Verified | Interest lost in both versions (Module 1, rule 12) |
| S14 | Balance 1,234.56, run D | 0.0422 | 0.0422 | No | Verified | Positive packed value, `C` sign half-byte |
| S15 | Balance 49,999.99, run D | 3.1095 | 3.1164 | **Yes** | Verified | One cent below tier 4 stays on tier 3, whose rate changes |
| S16 | Balance 10,000.00, accrued 0.0030, run M | Balance 10,000.62, accrued 0 | Balance 10,000.63, accrued 0 | **Yes** | Verified | The daily difference survives month-end rounding: 10,000.6249 rounds to .62, 10,000.6262 to .63 |

**Packed values:**
- S02 = `X'000000001D'`
- S13 = `X'999999999C'`
- S14 = `X'000123456C'`

Run `pack-records --hex` to show them.

**S05 and S16 together:** at month-end, S05 (no accrued interest) rounds to 10,000.62 in both versions, but S16 starts with 0.0030 accrued and ends one cent apart. Same balance, same rate change: whether month-end shows the difference depends on what is already accrued. That's why the rule says "may change" at month-end.

**Gap scenarios found by testers:** a frozen account at month-end is still capitalised (1,000.00 with 0.0050 accrued becomes 1,000.01), which proves rule 10. Accept it if a learner adds it.

**Note for the room:** in run D, S13 *does* change: 854.7945 becomes 856.1643. That's exactly the lesson's point that S13 is "No" only because the scenario uses the month-end run.

## What testing found (Skillable VM run, 7 November 2026, Claude Sonnet 5.5)

- **I Do packing demo:** `module-2/demo.csv` holds four records for the "packed decimal in one minute" demo. Run `python3 harness/pack-records.py --hex demo.csv` in the terminal: 1,234.56 shows `X'000123456C'` and -0.01 shows `X'000000001D'`, as in the lesson. The harness never adds `demo.csv` to a regression run.
- **The model's hex is not reliable; the tool's is.** In Step 3 the model correctly fixed a wrong packed value in its own Step 2 table (S19, -12,000.00: it had written `00 01 20 00 0D`, which is -1,200.00), then gave -0.01 as `00 00 00 01 1D` (that's -0.11) in the same answer. `pack-records --hex` settled it. A good room moment.
- **Step 2 table errors to look for:** a stray fragment left in a cell ("227.00 / 366 = 0.6201" beside the correct 0.6202186), and a wrong hex value inside a "Why it matters" note. Both are easy to read past.
- **M and L scenarios on the daily report.** A learner's month-end scenario (for example "10,000.00, month-end: No change") shows DIFFERENT in the daily report, because on run D it just accrues a day. That's not a mismatch. The lab's Step 2 now says to check D scenarios on the daily run and M or L scenarios on the stretch-task runs.
- **Step 4 found all six expected gaps** (closed, legal hold, bonus after a withdrawal, accrued overflow, a fifth rate record, an unexpected status) plus two file-level risks worth crediting: a program compiled against the wrong version of the copybook, and the old rate-file layout read by v2.
- **CSV editing traps, both seen in the VM:** a boundary file without a final line break (the first appended row joins the last one and `pack-records` rejects it), and a pasted row that landed mid-line and left the old row's tail on the end. Have learners rerun `pack-records --hex` after every edit.
- **Counts depend on the learner's own records.** With this key's 15 records the daily run is 3,540 / 1,472 / 3. A tester's 19 records (17 scenarios plus closed and bonus-after-withdrawal) gave 3,542 / 1,474 / 3. The 3 unexplained never change.

