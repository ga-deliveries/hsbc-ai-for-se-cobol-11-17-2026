# Module 2 Lab answer key: the unexplained differences

**Facilitator only.** Verified by running the harness on the course pack (GnuCOBOL 3.1, `-std=ibm`).

## Expected report, daily run D (`20261030,N`) with the 15 boundary records added

```text
3540 unchanged, 1472 changed as expected, 3 unexplained
(3540 unchanged includes 227 closed accounts dropped by both versions)
```

Without the boundary records (`--no-add`): 3531 unchanged, 1466 changed as expected, 3 unexplained.
The 6 extra "changed as expected" are S05, S07, S08, S13, S15 and S16. The full report is in `expected-report-daily-D.txt`.

## Background the data carries

Accounts `720000000101` to `720000000112` were migrated on 1 October 2026 from an acquired private bank. Its platform capitalised interest **once a year**. These accounts were last capitalised on 31 January 2026, and the migration carried their accrued interest and last-interest date across as they were.

Learners can see this in the data:
- **A different account-number range:** `7200...` instead of `7100...`.
- **An older last-interest date:** `ACCT-LAST-INT-DATE` is `20260131` instead of `20260930`.
- **Much larger accrued interest:** each migrated account holds exactly 271 days of daily interest (1 February – 29 October). Ordinary accounts hold 29 days, with the largest at 1,732.66.

## The three unexplained differences

All three come from the **same pre-existing defect**: `ACCT-ACCRUED-INT` is `PIC S9(5)V9(4)`, so it can't go above 99,999.9999. When a day's interest would push it over, `2000-ACCRUE-INTEREST` takes `ON SIZE ERROR`. The day's interest is not added, and an exception is written (Module 1, rule 9).

On monthly capitalisation the field can never fill: the largest possible month of interest, on the largest possible balance, is about 26,500. The migrated accounts carry nine months, and 30 October is the night their accrued interest reaches the edge.

| Account | What the report says | Why |
|---|---|---|
| `720000000104` | Changed as the rule predicts, but interest went **down** | Balance 4,300,986.40, accrued 99,632.0389. At the old rate (3.12%) tonight's interest of 367.6459 fits: accrued becomes 99,999.6848. At the new rate (3.125%) it is 368.2351 and overflows, so the **whole day is not added**. The rate increase leaves this customer 367.65 worse off tonight. |
| `720000000109` | Should change, but is **unchanged** | Balance 4,312,450.18, accrued 99,897.5918. Tonight's interest overflows in both versions, so both outputs are identical, even though the account is in the expected-change rule. |
| `720000000111` | Should change, but is **unchanged** | Same as `109`. Balance 4,308,715.92, accrued 99,811.0886. |

**Evidence learners should find:**
- **Exception reports:** `reports/exceptions-modified-20261030-N.txt` has an `ACCRUED INTEREST OVERFLOW - DAY NOT ADDED` line for `720000000104` that the original doesn't. The report's last section lists it as "only in modified".
- **Both versions overflow on two accounts:** both exception reports contain overflow lines for `720000000109` and `720000000111`.
- **The code:** the `ADD WS-DAILY-INT TO ACCT-ACCRUED-INT ON SIZE ERROR` statement in `2000-ACCRUE-INTEREST`, the `PIC` in `ACCTREC.cpy`, and rule 9 in their Module 1 spec.
- **The data:** the `7200` range and the `20260131` last-interest date, which explain why only these accounts are near the limit.

## What a good learner conclusion says

- **The change does what was asked.** 1,472 in-rule accounts changed, up, by the expected amounts, and the boundary records match the scenario table.
- **It exposes an existing capacity limit in `ACCT-ACCRUED-INT`.** The limit is harmless under monthly capitalisation, but not for accounts migrated with months of uncapitalised interest. From tonight, the three largest migrated accounts silently lose interest every night until the month-end run on 31 October capitalises it. Account `104` loses tonight *because of* the higher rate.
- **Verdict: safe with conditions.** Release the rate change, and raise the overflow as a separate defect. The fix could be a larger field, capitalising migrated accounts on arrival, or both. That's the same lesson as S13: parity is not correctness.

**Bonus insight for strong learners:** ask who checked the migrated accounts against `ACCTREC`'s field sizes before they were loaded. A migration that brings in values from a system with different rules is a classic source of this kind of defect.

## Other runs, if a learner tries them

| Run | Result | Note |
|---|---|---|
| M `20261031,Y` | 1 unexplained (`720000000104`) | The month-end run capitalises. `104` capitalises 367.64 less in the modified version: 4,400,618.44 against 4,400,986.08. `109` and `111` capitalise the same in both, and month-end accepts an unchanged in-rule account. |
| L `20280229,N` | 2 unexplained (`109`, `111`) | Dividing by 366 makes `104`'s new daily interest small enough to fit, so it changes normally. Good discussion point: the defect depends on the date. |

## A prompt that works for the explanation step

```text
Attach: INTCALC.cbl, INTCALC-v2.cbl, ACCTREC.cpy, the regression report,
and both exception reports.

For each unexplained difference in the regression report, explain the
cause. Cite the paragraph and line in INTCALC, the PIC clause involved,
and the matching line in the exception reports. Show the arithmetic for
the original and modified daily interest. Say whether the difference is
caused by the rate change or by existing behaviour that the rate change
exposes, and what in the input records makes these accounts different
from the rest.
```

## What testing found (Skillable VM run, 7 November 2026, Claude Sonnet 5.5)

- **The Task 3 explanation was right on all three accounts,** including every arithmetic step and the exception-report lines (original: 109 at line 298, 111 at 299; modified: 104 at 298, 109 at 299, 111 at 300).
- **What it missed:** the `7200` account range. It spotted the 31 January last-interest date but not the range, so it couldn't say the accounts came from somewhere else. Prompt the room: *"What do these three have in common that the other 4,997 don't?"*
- **Ask for the cost in money.** It said 104's accrued interest was "lower than the original"; the conclusion that matters is that the customer loses the whole day's interest, 367.65, because of a rate *increase*.
- **Hedges the report already settles.** It wrote "these are probably the only records that can overflow". The exception counts (299 against 300) already prove it.

