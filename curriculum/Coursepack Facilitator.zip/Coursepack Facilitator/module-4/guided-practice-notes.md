# Module 4 guided practice: facilitator notes (incident 1, S0C7)

The lesson's own expected results are the answer key. These notes record how the course pack supports them and where learners commonly slip.

## Numbers that agree across the evidence pack

| Fact | Where learners find it |
|---|---|
| Statement 142 = source line **164**, `WHEN ACCT-BALANCE NOT > ZERO` | `INTCALC-listing-excerpt.txt`, CEEDUMP traceback |
| Record 4,183 failed; 4,182 processed | CEEDUMP `WS-READ-CNT` 0004183 |
| 3,906 accounts accrued with the new rates | CEEDUMP `WS-ACCRUED-CNT` 0003906 |
| 4,182 = 3,906 accrued + 187 frozen + 31 closed + 58 zero/negative balance | CEEDUMP counters (written = 4,151 = 4,182 − 31 closed) |
| New rates loaded correctly: 0.500 / 1.250 / 2.275 / 3.125 | CEEDUMP `RATE-TIER-TABLE` |
| Failing account `710090001733` is in the onboarding range. **After masking (7100****1733) this can't be seen**, so the model will rightly say the link is "not established". The evidence that survives masking: `ACCT-TYPE` 'SV' and `ACCT-STATUS` 'A' are filled in and every byte from 16 on is spaces, the footprint of a 15-byte group move | CEEDUMP lines 48–56, `ACCTUPD-CR-48790.diff` lines 30 and 34–39 |
| 3 new accounts; master 4,194 → 4,197 | `ACCTUPD-sysout.txt`, SORT `ICE054I` in the job log |
| 4,197 = 4,182 regular + 3 onboarding + 12 migrated (`7200...`, sorted last) | Job log SORT counts |

## Traps built into the pack
- **Statement 142 vs line 142.** Source line 142 of `INTCALC.cbl` is a blank line between `0100` and `0200`. A model that treats the statement number as a line number lands on nothing, or invents a story about `0200-LOAD-RATE-TABLE`, which feeds the "rate change broke it" answer. The listing excerpt settles it.
- **Unmasked data to mask:** account numbers in the CEEDUMP (2: `710090001733`, and `710000004177` in `WS-EXC-ACCT-NUMBER`) and in the job log's EXCPTN excerpt (8, lines 106–113). Incident 2 holds more: 4 in `STMTPREP-joblog.txt`, and 4 account numbers plus 3 customer IDs in `dba-query.txt`. **Mask all of them at the start of guided practice**, before Step 1: Copilot reads files in the open folder on its own, even in Ask mode. Do **not** mask `ACCTUPD-CR-48790.diff`: its two numbers are the onboarding range limits, not accounts.
- **The vague prompt's favourite answer** is the rate change (CR-48812). The dump refutes it three ways: the new rate table is populated, the failing field is the balance and not a rate, and 3,906 accounts already accrued at the new rates.

## The ACCTUPD fix: one more trap
`INITIALIZE ACCT-REC` followed by the same `MOVE NEWACCT-REC TO ACCT-REC` is **not** a fix. The group MOVE still pads the remaining 85 bytes with spaces, overwriting the zeros `INITIALIZE` just set. The fix is `INITIALIZE ACCT-REC`, then move the elementary fields:
- `MOVE NA-ACCT-NUMBER TO ACCT-NUMBER`
- `MOVE NA-ACCT-TYPE TO ACCT-TYPE`
- `MOVE NA-ACCT-STATUS TO ACCT-STATUS`

The other option is a reference-modified move into the first 15 bytes after `INITIALIZE`. If a learner's AI proposes "add INITIALIZE before the MOVE", ask them to trace what's in `ACCT-BALANCE` afterwards.

## Verified in GnuCOBOL (build team)
- **ACCTUPD:** the `src` version was compiled and run with 3 onboarding records. It ended RC 0 and wrote the new accounts with spaces in `ACCT-BALANCE`, `ACCT-ACCRUED-INT`, `ACCT-LAST-INT-DATE`, `ACCT-BONUS-FLAG` and `ACCT-WITHDRAWALS-MTD`. That matches the lesson's "why didn't ACCTUPD abend" question.
- **INTCALC on the bad records:** with runtime checks (`-debug`), GnuCOBOL stops on `ACCT-BALANCE ... not numeric: '0x2020202020'`. GnuCOBOL reports it at the `COMPUTE` (line 192), because it doesn't check compares. z/OS raises the S0C7 earlier, at the packed compare on line 164 (statement 142). The evidence pack shows z/OS behaviour. Without `-debug`, GnuCOBOL processes the bad records silently. That's a good aside on why a real data exception is a gift.

## What testing found (November 2026, Copilot in Ask mode)

- **Copilot reads the folder on its own, even in Ask mode.** Asked the vague Step 1 question with only `INTCALC.cbl` attached, it opened the dump, job log, listing, calendar and ACCTUPD diff and found the real cause. So Step 1 has two possible outcomes. If it guesses from the one file, it blames the rate change: the original point. If it goes looking, have learners open the list of files it read and ask *"Who chose the evidence? Did it check for other bad records?"* It didn't. And if masking hadn't been done yet, it just read unmasked data: the strongest argument for masking first.
- **It skips the counters.** In 3 of 3 runs the model never used `WS-READ-CNT` 4,183 or `WS-ACCRUED-CNT` 3,906, the strongest evidence against the rate change. Without them it only calls the rate theory "less well supported". The lesson's Step 2 prompt now asks for the record counters; if a model still skips them, point learners to CEEDUMP lines 69 and 71.
- **It may drop the output format.** One run ignored Root cause | Confidence | Evidence | Ruled out | Next action and gave no Confidence or Next action. Ask for the format again: those two parts are what the 05:00 deadline needs.
- **Step 3's alternative may differ.** One run chose "the record was already bad, or came from another path" as the strongest alternative, not the rate change. Accept it; it's fair. It's ruled out by `ACCTUPD-sysout.txt` (3 new accounts last night) and the 15-byte footprint in the dump.
- **Step 3's "one check" is often wrong.** The model asked to trace the failing record's history instead of the key question: *are there other bad records?* If it misses it, ask outright: *"ACCTUPD added 3 accounts. What happens at about 3:30 if you fix only this one?"*
- **Recovery advice can be unsafe.** Runs proposed "don't rerun until ACCTUPD is fixed" and "rerun from a known-good master generation". The first misses the 05:00 window; the second throws away all of last night's account updates, not just 3 records. Ask: *"What else was on last night's master?"* The lesson's recovery: data fix on the 3 records, restart from STEP020, code fixes through a normal change. The lesson's starter instructions file now has a Recovery section.
- **Check the open folder before Step 4.** The Explorer's top line must say **MODULE-4**. One run had the whole course pack open and read `module-1/ACCTREC.cpy`; with `#codebase`, that would also search the `facilitator` folder.
- **Step 4's next-run times are in the change calendar,** not the code (FEEMTH Sat 22:00, STMTPREP Sun 03:45). The lesson's Step 4 prompt now attaches `change-calendar.md` and allows "the code and the change calendar". Expect a fifth row, `CUSTLINK`, from `incident-2`.
- **Typos in `#file:` can go unnoticed.** A mistyped `ACCTUPD-CR-48700.diff` attached nothing, but the model found the real file by itself, so the answer looked fine. Have learners pick files from the `#file:` list.

## What testing found (Skillable VM run, 7 November 2026, Claude Sonnet 5.5)

- **Masking in the VM:** Edit > Replace with the regex (`.*`) button works, and the match counts agree with the lesson (2, 8, 4, 4, then 3). Ctrl+H may not reach the VM, so teach the menu route. After Replace All, check the top of each file: one tester typed the find pattern into the file instead of the Find box, and saved it.
- **Step 1 went looking again,** read the masked evidence and found the ACCTUPD cause. This time it stated "INTCALC is not the faulty program" with no caveat, where Step 2 rated the same link "not established". Compare the two: same conclusion, very different honesty.
- **Level numbers cited as line numbers.** Step 1 cited "dump lines 31-45" for the record fields. Those are the dump's level numbers (31 `ACCT-NUMBER` to 45 `ACCT-WITHDRAWALS-MTD`); the fields are on lines 48-55. Step 2 cited `ACCT-WITHDRAWALS-MTD` at line 56 (it's 55; 56 is FILLER).
- **The counters were used this time:** `WS-READ-CNT` 4,183 and `WS-ACCRUED-CNT` 3,906 both appear in Step 2's ruling-out of the rate change.
- **Masking hides one link, as expected.** `7100****1733` can't show the onboarding range, so the model rated "this is one of the 3 new accounts" not established, and proved it from the 15-byte footprint instead.
- **The instructions file works.** After Step 5, the same lazy Step 1 question came back in Root cause | Confidence | Evidence | Ruled out | Next action form, listed the files it read, and opened Next action with "Recovery is your decision ... least change first".
