# Module 4 Lab answer key: SAVOPS-2317 (SQLCODE -811)

**Facilitator only.** Learners take the ticket through root cause, impact, proposed fix, test scenarios and a change (PR) description, using their playbook from the guided practice.

## Root cause

**CRMLOAD loaded the same 1,388-record delta into `SAV.ACCT_CUSTOMER` twice.**
- **Run 1 (21:14):** the LOAD step succeeded with 1,388 rows, then the image-copy step timed out (RC 8).
- **Run 2 (22:02):** the operator resubmitted the whole job. `LOAD ... RESUME YES` *appends*, so the same 1,388 rows went in again, with a later `LOAD_TS`.

Nothing stopped it. The unique index `ACI0` on `(ACCT_NUMBER, HOLDER_SEQ)` was dropped in 2019 for the joint-account migration (CR-31877) and never re-created. Only the non-unique `ACI1` remains.

CUSTLINK's singleton `SELECT ... WHERE ACCT_NUMBER = :ACCT-NUMBER AND PRIMARY_HOLDER = 'Y'` now finds two primary rows for every affected account. DB2 returns **SQLCODE -811**, and CUSTLINK's `WHEN OTHER` branch stops the run with RC 16. Account `710000002371` is simply the first affected account in key order.

**Evidence learners should cite:**
- **`dba-query.txt`:** two holder-1, primary `Y` rows that are identical except `LOAD_TS`, which is 21.15 for one and 22.04 for the other. Those times fall inside the two LOAD runs.
- **`CRMLOAD-joblog.txt`:** `RESUME YES`, the same SYSREC dataset both times, and 1,388 records loaded in each run.
- **`ACCT_CUSTOMER.sql`:** no unique index, and the comment about `ACI0`.
- **`CUSTLINK.cbl`, `2000-GET-PRIMARY-HOLDER`:** the singleton `SELECT` and the `EVALUATE SQLCODE` with `WHEN OTHER` setting RC 16.

**Hypotheses to rule out:**
- *"The rerun of STMTPREP caused it."* It failed identically before the rerun, at the same account.
- *"Joint accounts break the SELECT."* The `PRIMARY_HOLDER = 'Y'` predicate already handles joint accounts: holder 2 is `N`. It's the duplicate primary row.
- *"CUSTLINK changed."* There's no CUSTLINK change in the change calendar. The last change was in 2019.

## Impact

| Affected | How | Evidence |
|---|---|---|
| STMTPREP / CUSTLINK | Stops at the first duplicated account. Up to 1,388 accounts are affected | Job log, CRMLOAD counts |
| STMTMTH / STMTGEN | No extract, no statements. **Regulatory deadline Tue 3 Nov 12:00** | Ticket, `STMTXREC` header |
| STMTARCH | Reads the same extract (`STMTXREC` header). Archive index is not built | `STMTXREC.cpy` header |
| ACINQ01 (CICS inquiry) | Same table via `DCLACUST`. Online `-811` errors are already happening, with customer complaints | `DCLACUST.cpy` header, ticket ops note |
| CRMRECON (weekly batch) | Uses `DCLACUST`. Not established whether it uses a singleton `SELECT`. Check before its next run | `DCLACUST.cpy` header |
| CRMLOAD | Will do the same thing again on the next timeout and resubmit | Job log, restart practice |

**Learners should note:** STMTGEN, STMTARCH, ACINQ01 and CRMRECON are **not in the workspace**. Their exposure comes from copybook headers, which are claims, so list them as "per header, confirm by repository search". That's the same lesson as Module 1.

## Recovery: what to do before Tuesday
1. **Data fix, with DBA and change approval.** Delete the second copy of the 31 October delta: rows whose `LOAD_TS` falls in CRMLOAD run 2 (22:02–22:05). First run a count to confirm it's 1,388 rows and that each has a matching run-1 row.
2. **Verify the fix.** Run `SELECT ACCT_NUMBER, COUNT(*) FROM SAV.ACCT_CUSTOMER WHERE PRIMARY_HOLDER = 'Y' GROUP BY ACCT_NUMBER HAVING COUNT(*) > 1`. It should return no rows.
3. **Rerun.** Rerun STMTPREP, then release STMTMTH.

A data fix alone gets statements out and fixes ACINQ01 too. A CUSTLINK-only code change would leave ACINQ01 failing.

## Permanent fix: the proposal

| Change | Why |
|---|---|
| **Re-create unique index `ACI0` on `(ACCT_NUMBER, HOLDER_SEQ)`** after the cleanup | The database rejects the duplicate. The real control, missing since 2019 |
| **CRMLOAD restart procedure:** never resubmit a `RESUME YES` LOAD that completed; restart from the failed step, or make the load replace by key | Removes the trigger |
| **CUSTLINK:** handle `-811` explicitly by writing an exception ("MULTIPLE PRIMARY HOLDERS"), continuing, and ending RC 4. Keep RC 16 for real DB2 errors (e.g. `-904`) | One bad account no longer blocks a whole regulatory run |

**The trap to discuss:** many models suggest `FETCH FIRST 1 ROW ONLY` or `ORDER BY LOAD_TS DESC`. It makes the abend go away, but it hides the data problem, and it would pick an arbitrary holder if two *different* customers were both flagged primary. Make learners argue whether hiding the symptom is acceptable for statements going to customers.

## Test scenarios (expected minimum)

| # | Scenario | Expected |
|---|---|---|
| T1 | Account with one primary holder | Extract written |
| T2 | Joint account: holder 1 `Y`, holder 2 `N` | Extract for holder 1 only |
| T3 | No primary row (SQLCODE 100) | Exception "NO PRIMARY CUSTOMER LINK", run continues |
| T4 | Two identical primary rows (SQLCODE -811) | Exception "MULTIPLE PRIMARY HOLDERS", run continues, RC 4 |
| T5 | Two *different* customers both primary | Same as T4. Must not pick one silently |
| T6 | DB2 unavailable (e.g. SQLCODE -904) | Stops with RC 16, as today |
| T7 | Closed account | Skipped, counted, no lookup |
| T8 | After the data fix and index, CRMLOAD rerun of the same delta | LOAD rejects the duplicates (unique index). Table unchanged |

## Model change description (PR)

> **SAVOPS-2317: CUSTLINK: handle multiple primary holders without stopping the statement run**
>
> **Problem:** On 31 October, CRMLOAD loaded its delta twice (a `RESUME YES` resubmit after a timeout), creating duplicate primary-holder rows for 1,388 accounts. CUSTLINK's singleton SELECT got SQLCODE -811, and `WHEN OTHER` stopped STMTPREP with RC 16, blocking monthly statements. Root cause: unique index `ACI0` was dropped in 2019 (CR-31877) and never re-created.
>
> **Change:** In `2000-GET-PRIMARY-HOLDER`, `WHEN -811` writes an exception, "MULTIPLE PRIMARY HOLDERS - NO STATEMENT", counts it, and continues. `9000-TERMINATE` sets RC 4 when that count is above zero. Other negative SQLCODEs still end RC 16. No change to `STMTXREC`, `DCLACUST` or `ACCTREC`, so STMTGEN, STMTARCH, ACINQ01 and CRMRECON don't need recompiling.
>
> **Related changes, separate tickets:** data fix (DBA), re-create `ACI0` (DBA), CRMLOAD restart runbook (CRM team).
>
> **Testing:** scenarios T1–T8, with evidence attached.
>
> **Risk:** low. The new path only triggers on -811. Ops must treat RC 4 from STMTPREP as "review the exception report", not "success".

## What testing found (November 2026, Copilot in Ask mode)

- **Set the clock.** Without being told the scenario time, the model compares the ticket's deadline (Tue 3 Nov 2026 12:00) with today's real date and says it has already passed, then plans a "late issuance". Every future class runs after that date. The handout's Task 2 now starts the chat with *"Treat the current time as Sun 1 Nov 2026 04:12"*. Check learners sent it.
- **Unfilled placeholders.** A learner who pastes the self-challenge prompt without replacing `<the first theory you heard…>` gets a refusal to compare. That's the evidence rule working; point it out. The handout now supplies the night shift's theory: joint accounts, plus `FETCH FIRST 1 ROW ONLY`.
- **With that theory supplied,** the test run rejected both halves correctly: `PRIMARY_HOLDER = 'Y'` already excludes holder 2 (the `N` row, `dba-query.txt` line 11), and `FETCH FIRST 1 ROW ONLY` hides the duplicate. Without it, the joint-accounts hypothesis never came up.
- **The S0C7-shaped playbook prompt** asks for "every field the dump shows as invalid". Incident 2 has no dump, so the answer spends a paragraph on "not established". Expected; Task 5 now asks learners to generalise the prompt.
- **Confidence in the replay.** The model rated it "moderate", saying the pack doesn't prove which load wrote which row. The timestamps say otherwise: row 1 `LOAD_TS` 21:15:52 falls inside run 1's LOAD (21:14:07–21:16:39, `CRMLOAD-joblog.txt` lines 13 and 19); row 2, 22:04:13, inside run 2's (22:02:32–22:05:01, lines 41 and 47). Ask: *"What would you need to see to call this high, and is it already here?"*
- **The deadline can go missing from the impact list.** The test run listed all six affected programs and jobs, but never mentioned Tue 3 Nov 12:00. The Task 3 prompt now asks when customers would first notice and which deadline is at risk.
- **"Reconcile every duplicate against CRM first."** Safe, but unnecessary: the duplicate rows are identical except `LOAD_TS`, so either copy is correct. Ask: *"Is there anything to choose between?"*
- **"Fail closed" on -811.** The test run's fix stopped the run (RC 16) on a duplicate, with a clearer message. That still blocks every customer's statement next time. It's a design debate, not a wrong answer: a missing statement for one account (exception, RC 4) versus no statements at all.
- **The PR may keep RC 16.** The test run's PR was well structured, with the related work on separate tickets, but its change only improved the error message, and it used a cursor where a `WHEN -811` branch would do. Ask: *"Next month, if this happens again, do statements go out?"* Also check the PR says no copybook changed, so STMTGEN, STMTARCH, ACINQ01 and CRMRECON need no recompile.
- **Short test lists.** The run produced 5, then 6, scenarios. The Task 4 prompt now names all eight cases (T1–T8), including the closed account and rerunning the same delta after the fix.
- **A better point than the key's:** the model noted that re-creating `ACI0` on `(ACCT_NUMBER, HOLDER_SEQ)` cannot stop two *different* holders both being flagged primary (T5). Credit it if learners raise it; how to enforce "one primary per account" is a DBA design question.

## What testing found (Skillable VM run, 7 November 2026, Claude Sonnet 5.5)

- **Every earlier fix held:** the deadline was named, the night-shift theory was rejected on both counts, "nothing to choose between" replaced "reconcile with CRM first", the fix was a `WHEN -811` branch that writes an exception and continues, and the Task 4 table covered all eight cases plus three more. It also noticed that the run-2 image copy already holds the duplicates, so it isn't a clean restore point.
- **The clock may come from the files, not the learner.** A tester set the clock in a separate chat, yet every answer used Sun 1 Nov 04:12: the time is on the ticket, and the lab handout sat in the `module-4` folder where Copilot could read it, hints included. The handouts are now in `labs/`, outside the module folders. Teach: set the clock as the first message **in the same chat**.
- **Confidence in the replay is still marked down** ("medium-high", then "medium" after the self-challenge) even though each `LOAD_TS` falls inside its run's window. Ask the question above: *"What would you need to see to call this high, and is it already here?"*
- **Inconsistency across answers.** Task 2 said "nothing from the incident-1 change calendar applies here"; Task 3 then used `incident-1/change-calendar.md` for the STMTPREP and STMTMTH times (correctly, since it covers that weekend). Good practice in checking one answer against another.
- **A masking artefact the model found:** a tester's `dba-query.txt` had the find pattern `7100(\d{4})(\d{4})` typed into line 1. Copilot flagged it as stray text. Check the first line of each masked file.
- **The chat's + (add context) button may only offer folders** in some VS Code versions. Attach files with `#file:` or by dragging them from the Explorer.
