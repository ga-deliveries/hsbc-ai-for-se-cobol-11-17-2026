-- =================================================================
-- FEE_TABLES - DB2 tables used by FEEASSES (database SAVDB)
-- =================================================================

-- One row per account type per effective period.
-- FEEASSES selects the row whose period contains the run date.
CREATE TABLE SAV.FEE_SCHEDULE
  ( ACCT_TYPE        CHAR(2)       NOT NULL
  , EFFECTIVE_FROM   DATE          NOT NULL
  , EFFECTIVE_TO     DATE          NOT NULL
  , BASE_FEE         DECIMAL(5,2)  NOT NULL
  , WAIVER_BALANCE   DECIMAL(9,2)  NOT NULL
  , PRIMARY KEY (ACCT_TYPE, EFFECTIVE_FROM)
  );

-- One row per fee charged. The audit trail for every fee taken
-- from a customer's balance.
CREATE TABLE SAV.FEE_HISTORY
  ( ACCT_NUMBER      CHAR(12)      NOT NULL
  , FEE_DATE         DATE          NOT NULL
  , FEE_AMOUNT       DECIMAL(5,2)  NOT NULL
  , RECORDED_TS      TIMESTAMP     NOT NULL WITH DEFAULT
  , PRIMARY KEY (ACCT_NUMBER, FEE_DATE)
  );

-- Current schedule (as loaded in production)
INSERT INTO SAV.FEE_SCHEDULE VALUES ('SV', '2020-01-01', '2025-12-31', 4.00, 1000.00);
INSERT INTO SAV.FEE_SCHEDULE VALUES ('SV', '2026-01-01', '9999-12-31', 5.00, 1000.00);
INSERT INTO SAV.FEE_SCHEDULE VALUES ('BS', '2020-01-01', '9999-12-31', 7.50, 2500.00);
