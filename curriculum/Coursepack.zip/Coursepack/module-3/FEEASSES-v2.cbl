       IDENTIFICATION DIVISION.
       PROGRAM-ID.    FEEASSES.
       AUTHOR.        M A OKAFOR.
       DATE-WRITTEN.  1997-05-19.
      *================================================================*
      * FEEASSES - MONTHLY MAINTENANCE FEE ASSESSMENT, SAVINGS         *
      *                                                                *
      * RUNS IN JOB FEEMTH, STEP010, ON THE LAST CALENDAR DAY OF THE   *
      * MONTH. CHARGES THE MONTHLY FEE TO ACCOUNTS BELOW THE WAIVER    *
      * BALANCE, PLUS AN ACTIVITY FEE FOR EXCESS WITHDRAWALS, AND      *
      * WRITES THE NEW GENERATION OF THE ACCOUNT MASTER.               *
      *                                                                *
      * THE TOTAL MONTHLY FEE IS CAPPED AT 15.00 PER ACCOUNT, AS       *
      * REQUIRED BY REGULATORY NOTICE 17-114.                          *
      *                                                                *
      * PARM: CCYY-MM-DD[,OVERRIDE] - RUN DATE, OPTIONAL OPS OVERRIDE  *
      *----------------------------------------------------------------*
      * CHANGE LOG                                                     *
      * 1997-05-19  MAO  ORIGINAL                                      *
      * 2002-08-12  MAO  FEE SCHEDULE MOVED TO DB2 TABLE FEE_SCHEDULE  *
      * 2004-06-21  DLW  ACTIVITY FEE FOR WITHDRAWALS OVER 3 A MONTH   *
      * 2006-03-02  DLW  STUDENT SAVER FEE WAIVER                      *
      * 2008-10-27  JKB  OPS OVERRIDE - SKIP FEE_HISTORY ON RERUNS     *
      * 2011-02-07  DLW  STUDENT SAVER PRODUCT CLOSED                  *
      * 2017-11-30  SNA  15.00 MONTHLY FEE CAP - REG NOTICE 17-114     *
      * 2026-10-22  RKV  CR-48830 HIGH-ACTIVITY FEE TIER (7TH+ = 3.00) *
      *                  GO TO LOOP RESTRUCTURED, STRUCTURED CODE      *
      *================================================================*
       ENVIRONMENT DIVISION.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           SELECT ACCT-IN-FILE   ASSIGN TO ACCTIN
                  FILE STATUS IS WS-ACCTIN-STATUS.
           SELECT ACCT-OUT-FILE  ASSIGN TO ACCTOUT
                  FILE STATUS IS WS-ACCTOUT-STATUS.
           SELECT FEE-REPORT     ASSIGN TO FEERPT
                  FILE STATUS IS WS-FEERPT-STATUS.

       DATA DIVISION.
       FILE SECTION.
       FD  ACCT-IN-FILE
           RECORDING MODE IS F.
           COPY ACCTREC.

       FD  ACCT-OUT-FILE
           RECORDING MODE IS F.
       01  ACCT-OUT-REC                 PIC X(100).

       FD  FEE-REPORT
           RECORDING MODE IS F.
       01  FEE-REPORT-REC               PIC X(80).

       WORKING-STORAGE SECTION.
           EXEC SQL INCLUDE SQLCA END-EXEC.

       01  WS-FILE-STATUSES.
           05  WS-ACCTIN-STATUS         PIC X(02).
           05  WS-ACCTOUT-STATUS        PIC X(02).
           05  WS-FEERPT-STATUS         PIC X(02).

       01  WS-SWITCHES.
           05  WS-ACCT-EOF-SW           PIC X(01)       VALUE 'N'.
               88  END-OF-ACCOUNTS                 VALUE 'Y'.

       01  WS-OVERRIDE-CODE             PIC X(08)   VALUE 'OVRD2219'.

       01  WS-HOST-VARIABLES.
           05  WS-RUN-DATE              PIC X(10).
           05  WS-BASE-FEE              PIC S9(3)V99    COMP-3.
           05  WS-WAIVER-BAL            PIC S9(7)V99    COMP-3.

       01  WS-FEE-FIELDS.
           05  WS-ACTIVITY-FEE          PIC 9(03)V99.
           05  WS-TOTAL-FEE             PIC S9(3)V99    COMP-3.

       01  WS-COUNTERS.
           05  WS-READ-CNT              PIC 9(07)       VALUE ZERO.
           05  WS-WRITTEN-CNT           PIC 9(07)       VALUE ZERO.
           05  WS-FEE-CNT               PIC 9(07)       VALUE ZERO.
           05  WS-FEE-TOTAL             PIC 9(09)V99    VALUE ZERO.

       01  WS-REPORT-LINE.
           05  WS-RPT-ACCT-NUMBER       PIC X(12).
           05  FILLER                   PIC X(02)       VALUE SPACES.
           05  WS-RPT-ACCT-TYPE         PIC X(02).
           05  FILLER                   PIC X(02)       VALUE SPACES.
           05  WS-RPT-FEE               PIC ZZ9.99.
           05  FILLER                   PIC X(02)       VALUE SPACES.
           05  WS-RPT-NEW-BALANCE       PIC -Z,ZZZ,ZZ9.99.
           05  FILLER                   PIC X(02)       VALUE SPACES.
           05  WS-RPT-HISTORY           PIC X(12).
           05  FILLER                   PIC X(27)       VALUE SPACES.

       01  WS-DISPLAY-TOTAL             PIC Z,ZZZ,ZZZ,ZZ9.99.

       LINKAGE SECTION.
       01  LK-PARM.
           05  LK-PARM-LENGTH           PIC S9(04)      COMP.
           05  LK-PARM-DATA.
               10  LK-RUN-DATE          PIC X(10).
               10  FILLER               PIC X(01).
               10  LK-OVERRIDE          PIC X(08).

       PROCEDURE DIVISION USING LK-PARM.
      *----------------------------------------------------------------*
       0000-MAIN.
           PERFORM 0100-INITIALISE
           PERFORM 1000-PROCESS-ACCOUNT
               UNTIL END-OF-ACCOUNTS
           PERFORM 9000-TERMINATE
           GOBACK.

      *----------------------------------------------------------------*
       0100-INITIALISE.
           OPEN INPUT  ACCT-IN-FILE
                OUTPUT ACCT-OUT-FILE
                       FEE-REPORT
           IF WS-ACCTIN-STATUS NOT = '00'
               DISPLAY 'FEEASSES - OPEN FAILED. ACCTIN: '
                       WS-ACCTIN-STATUS
               MOVE 16 TO RETURN-CODE
               STOP RUN
           END-IF
           MOVE LK-RUN-DATE TO WS-RUN-DATE
           IF LK-PARM-LENGTH < 19
               MOVE SPACES TO LK-OVERRIDE
           END-IF
           PERFORM 8000-READ-ACCOUNT.

      *----------------------------------------------------------------*
       1000-PROCESS-ACCOUNT.
           MOVE ZERO TO WS-TOTAL-FEE

           IF NOT ACCT-CLOSED
              AND NOT ACCT-FROZEN
               PERFORM 2000-CALC-FEE
               IF WS-TOTAL-FEE > ZERO
                   PERFORM 3000-APPLY-FEE
               END-IF
           END-IF

           WRITE ACCT-OUT-REC FROM ACCT-REC
           ADD 1 TO WS-WRITTEN-CNT

           PERFORM 8000-READ-ACCOUNT.

      *----------------------------------------------------------------*
       2000-CALC-FEE.
           EXEC SQL
               SELECT BASE_FEE, WAIVER_BALANCE
                 INTO :WS-BASE-FEE, :WS-WAIVER-BAL
                 FROM FEE_SCHEDULE
                WHERE ACCT_TYPE = :ACCT-TYPE
                  AND :WS-RUN-DATE BETWEEN EFFECTIVE_FROM
                                       AND EFFECTIVE_TO
           END-EXEC

           EVALUATE TRUE
               WHEN SQLCODE = 100
                   CONTINUE
               WHEN SQLCODE NOT = 0
                   DISPLAY 'FEEASSES - FEE_SCHEDULE SQLCODE: ' SQLCODE
                   MOVE 16 TO RETURN-CODE
                   STOP RUN
               WHEN ACCT-BALANCE >= WS-WAIVER-BAL
                   CONTINUE
               WHEN OTHER
                   MOVE WS-BASE-FEE TO WS-TOTAL-FEE
                   PERFORM 2100-CALC-ACTIVITY-FEE
                   ADD WS-ACTIVITY-FEE TO WS-TOTAL-FEE
           END-EVALUATE.

       2050-APPLY-FEE-CAP.
           IF WS-TOTAL-FEE > 15.00
               MOVE 15.00 TO WS-TOTAL-FEE
           END-IF.

      *----------------------------------------------------------------*
      * CR-48830: WITHDRAWALS 4-6 = 2.00 EACH, 7TH AND OVER = 3.00 EACH
       2100-CALC-ACTIVITY-FEE.
           EVALUATE TRUE
               WHEN ACCT-WITHDRAWALS-MTD > 6
                   COMPUTE WS-ACTIVITY-FEE =
                       3 * 2.00 + (ACCT-WITHDRAWALS-MTD - 6) * 3.00
               WHEN ACCT-WITHDRAWALS-MTD > 3
                   COMPUTE WS-ACTIVITY-FEE =
                       (ACCT-WITHDRAWALS-MTD - 3) * 2.00
               WHEN OTHER
                   MOVE ZERO TO WS-ACTIVITY-FEE
           END-EVALUATE.

      *----------------------------------------------------------------*
       2500-APPLY-STUDENT-WAIVER.
           IF ACCT-TYPE = 'ST'
               MOVE ZERO TO WS-TOTAL-FEE
           END-IF.

      *----------------------------------------------------------------*
       3000-APPLY-FEE.
           SUBTRACT WS-TOTAL-FEE FROM ACCT-BALANCE

           MOVE ACCT-NUMBER  TO WS-RPT-ACCT-NUMBER
           MOVE ACCT-TYPE    TO WS-RPT-ACCT-TYPE
           MOVE WS-TOTAL-FEE TO WS-RPT-FEE
           MOVE ACCT-BALANCE TO WS-RPT-NEW-BALANCE

           IF LK-OVERRIDE = WS-OVERRIDE-CODE
               MOVE 'NOT RECORDED' TO WS-RPT-HISTORY
           ELSE
               MOVE 'RECORDED'     TO WS-RPT-HISTORY
               EXEC SQL
                   INSERT INTO FEE_HISTORY
                          (ACCT_NUMBER, FEE_DATE, FEE_AMOUNT)
                   VALUES (:ACCT-NUMBER, :WS-RUN-DATE, :WS-TOTAL-FEE)
               END-EXEC
           END-IF

           WRITE FEE-REPORT-REC FROM WS-REPORT-LINE
           ADD 1 TO WS-FEE-CNT
           ADD WS-TOTAL-FEE TO WS-FEE-TOTAL.

      *----------------------------------------------------------------*
       8000-READ-ACCOUNT.
           READ ACCT-IN-FILE
               AT END
                   SET END-OF-ACCOUNTS TO TRUE
               NOT AT END
                   ADD 1 TO WS-READ-CNT
           END-READ.

      *----------------------------------------------------------------*
       9000-TERMINATE.
           MOVE WS-FEE-TOTAL TO WS-DISPLAY-TOTAL
           DISPLAY 'FEEASSES - RUN DATE        : ' WS-RUN-DATE
           DISPLAY 'FEEASSES - ACCOUNTS READ   : ' WS-READ-CNT
           DISPLAY 'FEEASSES - ACCOUNTS WRITTEN: ' WS-WRITTEN-CNT
           DISPLAY 'FEEASSES - FEES CHARGED    : ' WS-FEE-CNT
           DISPLAY 'FEEASSES - TOTAL FEES      : ' WS-DISPLAY-TOTAL
           CLOSE ACCT-IN-FILE
                 ACCT-OUT-FILE
                 FEE-REPORT.
