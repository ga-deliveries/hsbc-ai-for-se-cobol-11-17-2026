      *================================================================*
      * SQLSTUB - STAND-INS FOR THE DB2 STATEMENTS IN FEEASSES         *
      * THE HARNESS REWRITES EACH EXEC SQL BLOCK AS A CALL TO ONE OF   *
      * THESE PROGRAMS. COURSE HARNESS ONLY - NOT PART OF THE LESSON.  *
      *                                                                *
      * SQLFSCH  SELECT ... FROM FEE_SCHEDULE   (TABLE = FEESCHED CSV) *
      * SQLFHIS  INSERT INTO FEE_HISTORY        (TABLE = FEEHIST CSV)  *
      *================================================================*
       IDENTIFICATION DIVISION.
       PROGRAM-ID.    SQLFSCH.
       ENVIRONMENT DIVISION.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           SELECT SCHED-FILE ASSIGN TO FEESCHED
                  ORGANIZATION IS LINE SEQUENTIAL.
       DATA DIVISION.
       FILE SECTION.
       FD  SCHED-FILE.
       01  SCHED-LINE                   PIC X(80).
       WORKING-STORAGE SECTION.
       01  WS-LOADED                    PIC X(01)       VALUE 'N'.
       01  WS-EOF                       PIC X(01)       VALUE 'N'.
       01  WS-COUNT                     PIC 9(02)       VALUE ZERO.
       01  WS-I                         PIC 9(02).
       01  WS-FIELDS.
           05  WS-F-TYPE                PIC X(10).
           05  WS-F-FROM                PIC X(10).
           05  WS-F-TO                  PIC X(10).
           05  WS-F-FEE                 PIC X(12).
           05  WS-F-WAIVER              PIC X(12).
       01  WS-TABLE.
           05  WS-ROW OCCURS 20 TIMES.
               10  WS-T-TYPE            PIC X(02).
               10  WS-T-FROM            PIC X(10).
               10  WS-T-TO              PIC X(10).
               10  WS-T-FEE             PIC S9(3)V99    COMP-3.
               10  WS-T-WAIVER          PIC S9(7)V99    COMP-3.
       LINKAGE SECTION.
       01  LK-BASE-FEE                  PIC S9(3)V99    COMP-3.
       01  LK-WAIVER-BAL                PIC S9(7)V99    COMP-3.
       01  LK-ACCT-TYPE                 PIC X(02).
       01  LK-RUN-DATE                  PIC X(10).
       01  LK-SQLCODE                   PIC S9(9)       COMP-5.
       PROCEDURE DIVISION USING LK-BASE-FEE LK-WAIVER-BAL
                                LK-ACCT-TYPE LK-RUN-DATE LK-SQLCODE.
           IF WS-LOADED = 'N'
               OPEN INPUT SCHED-FILE
               PERFORM UNTIL WS-EOF = 'Y'
                   READ SCHED-FILE
                       AT END MOVE 'Y' TO WS-EOF
                       NOT AT END
                           UNSTRING SCHED-LINE DELIMITED BY ','
                               INTO WS-F-TYPE WS-F-FROM WS-F-TO
                                    WS-F-FEE WS-F-WAIVER
                           END-UNSTRING
                           ADD 1 TO WS-COUNT
                           MOVE WS-F-TYPE TO WS-T-TYPE (WS-COUNT)
                           MOVE WS-F-FROM TO WS-T-FROM (WS-COUNT)
                           MOVE WS-F-TO   TO WS-T-TO   (WS-COUNT)
                           COMPUTE WS-T-FEE (WS-COUNT) =
                               FUNCTION NUMVAL (WS-F-FEE)
                           COMPUTE WS-T-WAIVER (WS-COUNT) =
                               FUNCTION NUMVAL (WS-F-WAIVER)
                   END-READ
               END-PERFORM
               CLOSE SCHED-FILE
               MOVE 'Y' TO WS-LOADED
           END-IF
           MOVE 100 TO LK-SQLCODE
           PERFORM VARYING WS-I FROM 1 BY 1 UNTIL WS-I > WS-COUNT
               IF WS-T-TYPE (WS-I) = LK-ACCT-TYPE
                  AND LK-RUN-DATE >= WS-T-FROM (WS-I)
                  AND LK-RUN-DATE <= WS-T-TO (WS-I)
                   MOVE WS-T-FEE (WS-I)    TO LK-BASE-FEE
                   MOVE WS-T-WAIVER (WS-I) TO LK-WAIVER-BAL
                   MOVE 0 TO LK-SQLCODE
               END-IF
           END-PERFORM
           GOBACK.
       END PROGRAM SQLFSCH.

       IDENTIFICATION DIVISION.
       PROGRAM-ID.    SQLFHIS.
       ENVIRONMENT DIVISION.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           SELECT OPTIONAL HIST-FILE ASSIGN TO FEEHIST
                  ORGANIZATION IS LINE SEQUENTIAL.
       DATA DIVISION.
       FILE SECTION.
       FD  HIST-FILE.
       01  HIST-LINE                    PIC X(40).
       WORKING-STORAGE SECTION.
       01  WS-OPEN                      PIC X(01)       VALUE 'N'.
       01  WS-AMOUNT                    PIC ZZ9.99.
       LINKAGE SECTION.
       01  LK-ACCT-NUMBER               PIC X(12).
       01  LK-FEE-DATE                  PIC X(10).
       01  LK-FEE-AMOUNT                PIC S9(3)V99    COMP-3.
       01  LK-SQLCODE                   PIC S9(9)       COMP-5.
       PROCEDURE DIVISION USING LK-ACCT-NUMBER LK-FEE-DATE
                                LK-FEE-AMOUNT LK-SQLCODE.
           IF WS-OPEN = 'N'
               OPEN EXTEND HIST-FILE
               MOVE 'Y' TO WS-OPEN
           END-IF
           MOVE LK-FEE-AMOUNT TO WS-AMOUNT
           MOVE SPACES TO HIST-LINE
           STRING LK-ACCT-NUMBER ',' LK-FEE-DATE ','
                  FUNCTION TRIM (WS-AMOUNT)
                  DELIMITED BY SIZE INTO HIST-LINE
           END-STRING
           WRITE HIST-LINE
           MOVE 0 TO LK-SQLCODE
           GOBACK.
       END PROGRAM SQLFHIS.
