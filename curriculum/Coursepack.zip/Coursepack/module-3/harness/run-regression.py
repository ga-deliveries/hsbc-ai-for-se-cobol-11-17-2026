"""run-regression: run the original FEEASSES and the refactored FEEASSES-v2 on the
same month-end account master and compare the fees they charge.

Usage:
  python3 harness/run-regression.py [--parm 2026-10-31]

What it does, as the FEEMTH job would on z/OS:
  1. Compiles FEEASSES.cbl and FEEASSES-v2.cbl. DB2 isn't available here, so each
     EXEC SQL block is swapped, for the compile only, for a CALL to a stand-in
     (SQLSTUB.cbl) that reads FEE_SCHEDULE from fee-schedule.csv and writes
     FEE_HISTORY rows to a file. The source files themselves are not changed.
  2. Runs both versions with the same PARM on data/ACCTMAST-20261031.dat.
  3. Compares the fee each version charged every account, and writes a report.

Expected-change rule used to classify differences (from CR-48830):
  The new tier only changes the activity fee from the 7th withdrawal. An
  account's fee may change only if it is not closed or frozen, its balance is
  below the waiver balance for its type, and it made 7 or more withdrawals.
  A fee may only go up, and the total fee must never exceed the 15.00 monthly
  cap (regulatory notice 17-114).
"""
import argparse, csv, os, re, shutil, subprocess, sys
from decimal import Decimal
from datetime import datetime

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from acctrec import unpack_record, read_records, FIELDS

MODULE = os.path.dirname(HERE)
WORK = os.path.join(HERE, "work")
REPORTS = os.path.join(MODULE, "reports")
EXE = ".exe" if os.name == "nt" else ""
CAP = Decimal("15.00")
STUBS = {"FEE_SCHEDULE": "SQLFSCH", "FEE_HISTORY": "SQLFHIS"}


def sql_to_calls(src):
    """Replace EXEC SQL ... END-EXEC with CALLs to the stand-in programs."""
    src = re.sub(r"^ {7}\s*EXEC SQL INCLUDE SQLCA END-EXEC\.\s*$",
                 "       01  SQLCA.\n           05  SQLCODE              PIC S9(9) COMP-5.",
                 src, flags=re.M)

    def repl(m):
        body, period = m.group(1), m.group(2) or ""
        table = next((t for t in STUBS if t in body), None)
        if not table:
            sys.exit(f"Harness cannot stand in for this SQL statement:\n{body}")
        hosts = re.findall(r":([A-Z0-9-]+)", body)
        indent = " " * 11
        args = "\n".join(f"{indent}    {h}" for h in hosts + ["SQLCODE"])
        return f"{indent}CALL '{STUBS[table]}' USING\n{args}{period}"
    return re.sub(r"^ +EXEC SQL\n(.*?)\n +END-EXEC(\.?)$", repl, src, flags=re.M | re.S)


def compile_version(name, program):
    os.makedirs(WORK, exist_ok=True)
    src = open(os.path.join(MODULE, program)).read()
    pp = os.path.join(WORK, f"{name}-{program}")
    open(pp, "w").write(sql_to_calls(src))
    exe = os.path.join(WORK, f"feeasses-{name}{EXE}")
    cmd = ["cobc", "-std=ibm", "-x", "-o", exe, os.path.join(HERE, "PARMDRV.cbl"), pp,
           os.path.join(HERE, "SQLSTUB.cbl"), "-I", MODULE]
    p = subprocess.run(cmd, capture_output=True, text=True, cwd=WORK)
    if p.returncode != 0:
        sys.exit(f"Compile of {program} failed:\n{p.stdout}{p.stderr}")
    return exe


def run_version(name, exe, acctin, parm):
    out = {k: os.path.join(WORK, f"{k}-{name}.dat") for k in ("ACCTOUT", "FEERPT", "FEEHIST")}
    if os.path.exists(out["FEEHIST"]):
        os.remove(out["FEEHIST"])
    env = dict(os.environ, DD_ACCTIN=acctin, DD_ACCTOUT=out["ACCTOUT"], DD_FEERPT=out["FEERPT"],
               DD_FEEHIST=out["FEEHIST"], DD_FEESCHED=os.path.join(HERE, "fee-schedule.csv"))
    p = subprocess.run([exe, parm], env=env, capture_output=True, text=True)
    if p.returncode != 0:
        sys.exit(f"{name} run ended with return code {p.returncode}:\n{p.stdout}{p.stderr}")
    hist = {}
    if os.path.exists(out["FEEHIST"]):
        for line in open(out["FEEHIST"]):
            acct, date, amt = line.strip().split(",")
            hist[acct] = Decimal(amt)
    rpt = open(out["FEERPT"], "rb").read()
    rpt_lines = [rpt[i:i + 80].decode().rstrip() for i in range(0, len(rpt), 80)]
    return out["ACCTOUT"], hist, rpt_lines, p.stdout.strip().splitlines()


def schedule(run_date):
    sched = {}
    for row in csv.reader(open(os.path.join(HERE, "fee-schedule.csv"))):
        if row and row[1] <= run_date <= row[2]:
            sched[row[0]] = Decimal(row[4])
    return sched


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--parm", default="2026-10-31")
    ap.add_argument("--accounts", default=os.path.join(MODULE, "data", "ACCTMAST-20261031.dat"))
    a = ap.parse_args()
    os.makedirs(REPORTS, exist_ok=True)
    run_date = a.parm[:10]
    waiver = schedule(run_date)

    exe_o = compile_version("original", "FEEASSES.cbl")
    exe_m = compile_version("modified", "FEEASSES-v2.cbl")
    out_o, hist_o, rpt_o, log_o = run_version("original", exe_o, a.accounts, a.parm)
    out_m, hist_m, rpt_m, log_m = run_version("modified", exe_m, a.accounts, a.parm)

    inp = {r[:12].decode().strip(): unpack_record(r) for r in read_records(a.accounts)}
    o = {r[:12].decode().strip(): unpack_record(r) for r in read_records(out_o)}
    m = {r[:12].decode().strip(): unpack_record(r) for r in read_records(out_m)}

    unchanged = expected = 0
    unexplained = []
    for acct, rec in inp.items():
        ro, rm = o.get(acct), m.get(acct)
        if ro is None or rm is None:
            unexplained.append((acct, "On one output file but not the other", rec, None, None))
            continue
        fee_o = rec["ACCT-BALANCE"] - ro["ACCT-BALANCE"]
        fee_m = rec["ACCT-BALANCE"] - rm["ACCT-BALANCE"]
        other_same = all(ro[f] == rm[f] for f in FIELDS if f != "ACCT-BALANCE")
        in_rule = (rec["ACCT-STATUS"] not in ("C", "F", "L")
                   and rec["ACCT-TYPE"] in waiver and rec["ACCT-BALANCE"] < waiver[rec["ACCT-TYPE"]]
                   and int(rec["ACCT-WITHDRAWALS-MTD"]) >= 7)
        if fee_o == fee_m and other_same:
            unchanged += 1
            continue
        if fee_m > CAP:
            unexplained.append((acct, "Modified fee is ABOVE the 15.00 monthly cap (regulatory notice 17-114)",
                                rec, fee_o, fee_m))
        elif not other_same:
            unexplained.append((acct, "A field other than the balance changed", rec, fee_o, fee_m))
        elif not in_rule:
            unexplained.append((acct, "Fee CHANGED, but outside the CR-48830 rule", rec, fee_o, fee_m))
        elif fee_m < fee_o:
            unexplained.append((acct, "Fee went DOWN; CR-48830 only raises fees", rec, fee_o, fee_m))
        else:
            expected += 1

    hist_gap_o = sum(1 for k, r in inp.items() if o.get(k) and r["ACCT-BALANCE"] != o[k]["ACCT-BALANCE"]
                     and k not in hist_o)
    hist_gap_m = sum(1 for k, r in inp.items() if m.get(k) and r["ACCT-BALANCE"] != m[k]["ACCT-BALANCE"]
                     and k not in hist_m)

    lines = []
    w = lines.append
    w("=" * 78)
    w("FEEASSES REGRESSION REPORT   original (FEEASSES) vs modified (FEEASSES-v2)")
    w("=" * 78)
    w(f"Run PARM         : {a.parm}")
    w(f"Produced         : {datetime.now():%Y-%m-%d %H:%M}")
    w(f"Input records    : {len(inp)}   ({os.path.basename(a.accounts)})")
    w(f"Fee schedule     : fee-schedule.csv (stand-in for DB2 table FEE_SCHEDULE)")
    w("")
    w(f"  {unchanged} unchanged, {expected} changed as expected, {len(unexplained)} unexplained")
    w("")
    w("Expected-change rule (CR-48830): fee may change only if the account is not")
    w("closed or frozen, is below its waiver balance, and made 7+ withdrawals.")
    w("Fees may only go up, and no total fee may exceed 15.00.")
    w("")
    w("-" * 78)
    w(f"UNEXPLAINED DIFFERENCES ({len(unexplained)})")
    w("-" * 78)
    if not unexplained:
        w("None.")
    else:
        reasons = sorted({why for _, why, *_ in unexplained})
        code = {why: chr(ord("A") + i) for i, why in enumerate(reasons)}
        for why in reasons:
            n = sum(1 for u in unexplained if u[1] == why)
            w(f"  [{code[why]}] {why}  ({n})")
        w("")
        w("  Account       Type Status    Balance  Withdrawals  Fee: original  modified  Reason")
        for acct, why, rec, fo, fm in unexplained:
            fees = f"{fo:>14}  {fm:>8}" if fo is not None else f"{'-':>14}  {'-':>8}"
            w(f"  {acct}  {rec['ACCT-TYPE']:<4} {rec['ACCT-STATUS']:<6} {rec['ACCT-BALANCE']:>10}  "
              f"{int(rec['ACCT-WITHDRAWALS-MTD']):>11}  {fees}  [{code[why]}]")
        w("")
    w("-" * 78)
    w("FEES CHARGED")
    w("-" * 78)
    tot_o = sum(rec["ACCT-BALANCE"] - o[k]["ACCT-BALANCE"] for k, rec in inp.items() if k in o)
    tot_m = sum(rec["ACCT-BALANCE"] - m[k]["ACCT-BALANCE"] for k, rec in inp.items() if k in m)
    max_o = max((rec["ACCT-BALANCE"] - o[k]["ACCT-BALANCE"] for k, rec in inp.items() if k in o), default=0)
    max_m = max((rec["ACCT-BALANCE"] - m[k]["ACCT-BALANCE"] for k, rec in inp.items() if k in m), default=0)
    w(f"   original: {len(rpt_o):>5} fees, total {tot_o:>10}, largest single fee {max_o}")
    w(f"   modified: {len(rpt_m):>5} fees, total {tot_m:>10}, largest single fee {max_m}")
    w(f"   FEE_HISTORY rows: original {len(hist_o)}, modified {len(hist_m)}")
    w(f"   Fees charged with no FEE_HISTORY row: original {hist_gap_o}, modified {hist_gap_m}")
    w("")
    w("-" * 78)
    w("PROGRAM COUNTS")
    w("-" * 78)
    for name, log in (("original", log_o), ("modified", log_m)):
        w(f"[{name}]")
        lines.extend("   " + x for x in log)

    tag = run_date
    for name, rpt in (("original", rpt_o), ("modified", rpt_m)):
        open(os.path.join(REPORTS, f"fee-report-{name}-{tag}.txt"), "w").write("\n".join(rpt) + "\n")
    w("")
    w(f"Fee reports saved as reports/fee-report-original-{tag}.txt and fee-report-modified-{tag}.txt")
    report = "\n".join(lines)
    name = os.path.join(REPORTS, f"regression-FEEASSES-{tag}.txt")
    open(name, "w").write(report + "\n")
    print(report)
    print(f"\nReport saved to {name}")


if __name__ == "__main__":
    main()
