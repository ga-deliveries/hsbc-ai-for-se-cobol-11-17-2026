MODULE 3 HARNESS

HOW TO RUN IT 

  VS Code (recommended)
    Open the module-3 folder (File > Open Folder), then
    Terminal > Run Task... > Run regression: FEEASSES vs FEEASSES-v2 (2026-10-31)
    or press Ctrl+Shift+B.

  Linux terminal (from the module-3 folder)
    harness/run-regression.sh


WHAT IT DOES

run-regression
  Runs the original FEEASSES and the developer's FEEASSES-v2 on the same
  month-end account master (data/ACCTMAST-20261031.dat), compares the
  fee each one charged every account, and writes a report.

  DB2 is not available on this machine. For the run only, the harness swaps each
  EXEC SQL statement for a call to a stand-in (SQLSTUB.cbl):
    FEE_SCHEDULE  is read from fee-schedule.csv (same rows as FEE_TABLES.sql)
    FEE_HISTORY   rows are written to a file and counted in the report
  The .cbl files you review are not changed.

  Results go to the reports folder:
    regression-FEEASSES-2026-10-31.txt         the report
    fee-report-original-2026-10-31.txt         FEEASSES's fee report (FEERPT)
    fee-report-modified-2026-10-31.txt         FEEASSES-v2's fee report

The report's first line is the one to read:
    N unchanged, M changed as expected, X unexplained
The expected-change rule comes from CR-48830 (CR-48830.md).
