import os, subprocess, sys
from decimal import Decimal as D

V = os.path.dirname(os.path.abspath(__file__))

def pack(value, digits, scale):
    n = int((D(value) * (10 ** scale)).to_integral_value())
    sign = 'D' if n < 0 else 'C'
    s = str(abs(n)).rjust(digits, '0')
    h = s + sign
    if len(h) % 2: h = '0' + h
    return bytes.fromhex(h)

def unpack(b, scale):
    h = b.hex().upper()
    sign = -1 if h[-1] == 'D' else 1
    return D(sign * int(h[:-1])) / (10 ** scale)

def rec(num, typ, st, bal, acc='0', date='20260930', bonus='N', wd=0):
    r = num.ljust(12).encode() + typ.encode() + st.encode()
    r += pack(bal, 9, 2) + pack(acc, 9, 4)
    r += date.encode() + bonus.encode() + str(wd).rjust(3, '0').encode()
    r += b' ' * 63
    assert len(r) == 100, len(r)
    return r

def parse(r):
    return dict(num=r[0:12].decode().strip(), type=r[12:14].decode(), status=r[14:15].decode(),
                bal=unpack(r[15:20], 2), acc=unpack(r[20:25], 4), date=r[25:33].decode(),
                wd=r[34:37].decode())

def rates(extra_tier=False):
    rows = [('00000', '0050'), ('01000', '0125'), ('10000', '0227'), ('50000', '0312')]
    if extra_tier: rows.append(('99999', '0999'))
    return b''.join((f + r).encode().ljust(80) for f, r in rows)

# Module 2 Figure 05 scenarios + extra rule checks
recs = [
    rec('BND000000001', 'SV', 'A', '0.00'),
    rec('BND000000002', 'SV', 'A', '-0.01'),
    rec('BND000000003', 'SV', 'A', '1000.00'),
    rec('BND000000004', 'SV', 'A', '999.99'),
    rec('BND000000005', 'SV', 'A', '10000.00'),
    rec('BND000000006', 'SV', 'A', '9999.99'),
    rec('BND000000007', 'SV', 'A', '50000.00'),
    rec('BND000000008', 'BS', 'A', '20000.00', bonus='Y'),
    rec('BND000000009', 'SV', 'D', '20000.00'),
    rec('BND000000011', 'SV', 'A', '100.00', acc='0.0037'),
    rec('BND000000012', 'SV', 'A', '100.00', acc='0.0036'),
    rec('BND000000013', 'SV', 'A', '9999999.99'),
    rec('BND000000014', 'SV', 'A', '1234.56'),
    # extra rule checks
    rec('RUL000000001', 'SV', 'C', '5000.00', acc='1.0000'),      # rule 1 closed dropped
    rec('RUL000000002', 'SV', 'F', '5000.00', acc='1.0000'),      # rule 2 frozen
    rec('RUL000000003', 'SV', 'L', '5000.00', acc='1.0000'),      # rule 2 legal hold
    rec('RUL000000004', 'BS', 'A', '20000.00', bonus='Y', wd=1),  # rule 6 bonus lost
    rec('RUL000000005', 'BS', 'D', '20000.00', bonus='Y'),        # rule 6 dormant bonus saver
    rec('RUL000000006', 'SV', 'A', '50000.00', acc='99999.9990'), # rule 9 accrued overflow
    rec('RUL000000007', 'SV', 'X', '1000.00'),                    # unexpected status -> OTHER
    rec('RUL000000008', 'SV', 'A', '-50.00', acc='0.5000'),       # rule 10 overdrawn capitalised
]
open(os.path.join(V, 'acctin.dat'), 'wb').write(b''.join(recs))

def run(parm, extra_tier=False, tag=''):
    open(os.path.join(V, 'rates.dat'), 'wb').write(rates(extra_tier))
    env = dict(os.environ, DD_ACCTIN=os.path.join(V, 'acctin.dat'), DD_RATEIN=os.path.join(V, 'rates.dat'),
               DD_ACCTOUT=os.path.join(V, f'acctout{tag}.dat'), DD_EXCPTN=os.path.join(V, f'excptn{tag}.txt'))
    p = subprocess.run([os.path.join(V, 'intcalc'), parm], env=env, capture_output=True, text=True)
    out = open(os.path.join(V, f'acctout{tag}.dat'), 'rb').read()
    recs_out = {x['num']: x for x in (parse(out[i:i+100]) for i in range(0, len(out), 100))}
    exc = open(os.path.join(V, f'excptn{tag}.txt'), 'rb').read()
    excs = [exc[i:i+80].decode().rstrip() for i in range(0, len(exc), 80)]
    return p.stdout + p.stderr, recs_out, excs

results = []
def check(label, got, want):
    ok = (D(str(got)) == D(str(want))) if isinstance(got, D) else str(got) == str(want)
    results.append(ok)
    print(f"{'PASS' if ok else 'FAIL'}  {label}: got {got}, want {want}")

logD, d, excD = run('20261030,N', tag='D')
logM, m, excM = run('20261031,Y', tag='M')
logL, l, excL = run('20280229,N', tag='L')
log5, d5, _ = run('20261030,N', extra_tier=True, tag='5')

print(logD)
# Figure 05 daily expected accruals (original program)
for num, want in [('BND000000001', '0.0000'), ('BND000000002', '0.0000'), ('BND000000003', '0.0342'),
                  ('BND000000004', '0.0136'), ('BND000000005', '0.6219'), ('BND000000006', '0.3424'),
                  ('BND000000007', '4.2739'), ('BND000000008', '1.5178'), ('BND000000009', '0.2739'),
                  ('BND000000014', '0.0422')]:
    check(f'{num[-2:]} run D accrued', d[num]['acc'], want)
check('S10 run L accrued (leap year)', l['BND000000003']['acc'], '0.0341')
check('S11 run M balance', m['BND000000011']['bal'], '100.01')
check('S11 run M accrued reset', m['BND000000011']['acc'], '0.0000')
check('S12 run M balance', m['BND000000012']['bal'], '100.00')
check('S13 run M balance unchanged', m['BND000000013']['bal'], '9999999.99')
check('S13 run M accrued reset (interest lost)', m['BND000000013']['acc'], '0.0000')
check('S02 sign kept', d['BND000000002']['bal'], '-0.01')
check('Rule 1 closed account dropped from master', 'RUL000000001' in d, False)
check('Rule 2 frozen F no accrual', d['RUL000000002']['acc'], '1.0000')
check('Rule 2 legal hold L no accrual', d['RUL000000003']['acc'], '1.0000')
check('Rule 2 two FROZEN exceptions', sum('FROZEN' in e for e in excD), 2)
check('Rule 6 bonus lost after a withdrawal (tier 3 only)', d['RUL000000004']['acc'], '1.2438')
check('Rule 6 dormant bonus saver gets tier 1 + bonus', d['RUL000000005']['acc'], '0.5479')
check('Rule 9 accrued overflow: day not added', d['RUL000000006']['acc'], '99999.9990')
check('Rule 9 overflow exception written', any('ACCRUED INTEREST OVERFLOW' in e for e in excD), True)
check('Unexpected status X earns interest', d['RUL000000007']['acc'], '0.0342')
check('Rule 10 frozen capitalised at month end', m['RUL000000002']['bal'], '5001.00')
check('Rule 10 overdrawn capitalised at month end', m['RUL000000008']['bal'], '-49.50')
check('Rule 11 withdrawals reset at month end', m['RUL000000004']['wd'], '000')
check('Rule 11 last-interest date = run date', m['BND000000003']['date'], '20261031')
check('Rule 12 balance overflow exception', any('BALANCE OVERFLOW' in e for e in excM), True)
check('Rule 13 fifth rate tier ignored', d5['BND000000013']['acc'], d['BND000000013']['acc'])
check('Rule 13 tiers loaded = 4', 'RATE TIERS      : 4' in log5, True)
print(f"\n{sum(results)}/{len(results)} checks passed")
