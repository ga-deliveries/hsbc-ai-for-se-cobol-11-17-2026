INTCALC verification kit (for the course build team, not learners)

PARMDRV.cbl  Test driver. Passes a JCL-style PARM (halfword length + data)
             from the command line to INTCALC, the way z/OS does from EXEC PARM.
verify.py    Builds 21 synthetic ACCTREC records (the 13 Module 2 boundary
             records S01-S14 plus 8 extra business-rule checks), writes a
             4-tier rate file, runs INTCALC for runs D (20261030,N),
             M (20261031,Y) and L (20280229,N), and checks every result
             against the Module 1 rules and the Module 2 Figure 05 values.

Build and run (GnuCOBOL 3.x, Python 3):
  cobc -std=ibm -x -o intcalc PARMDRV.cbl ../module-1/INTCALC.cbl -I ../module-1
  python3 verify.py

DD names map to files through environment variables (DD_ACCTIN, DD_RATEIN,
DD_ACCTOUT, DD_EXCPTN), which stands in for the JCL in EODINT.
Rate file record (80 bytes): floor 9(05) whole units, rate 9(02)V99, filler.
