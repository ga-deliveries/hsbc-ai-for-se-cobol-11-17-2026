# Savings batch: change calendar

**Changes implemented Friday 30 October 2026.** All were approved at Thursday's Change Advisory Board.

| Change | Time | Program / job | What changed | Implementer | Risk | Backout |
|---|---|---|---|---|---|---|
| CR-48790 | 18:30 | `ACCTUPD` (job `ACCTDLY`) | Add accounts opened through the new digital onboarding feed (`DIGONB`) to the account master | T. Lindqvist | Low | Restore previous load module, remove `DIGONB` DD |
| CR-48801 | 19:00 | `STMTGEN` (job `STMTMTH`) | New regulatory footer text on monthly statements | P. Osei | Low | Restore previous load module |
| CR-48812 | 19:15 | `INTCALC` (job `EODINT`), `RATETIER` copybook, `PROD.SAV.RATETIER.CURRENT` | Tier interest rates carried to 3 decimal places. Rate file reformatted by `RATEPUB` the same evening | P. Varma | Medium | Restore previous load module and rate file generation |

## Batch schedule, night of 30–31 October

| Job | Scheduled | Programs | Notes |
|---|---|---|---|
| `ACCTDLY` | Fri 23:30 | `ACCTUPD` | Writes new account master generation |
| `RATEPUB` | Fri 23:50 | rate file publish | New 3-decimal layout (CR-48812) |
| `EODINT` | Sat 02:05 | SORT, `INTCALC` | Must finish by **05:00**, when the online day starts |
| `FEEMTH` | Sat 22:00 | `FEEASSES` | Month-end fee run, PARM `2026-10-31` |
| `EODINT` | Sun 02:05 | SORT, `INTCALC` | Month-end interest capitalisation, PARM `20261031,Y` |
| `STMTPREP` | Sun 03:45 | `CUSTLINK` | Statement extract (links accounts to customers) |
| `STMTMTH` | Sun 06:00 | `STMTGEN` | Monthly statements |
