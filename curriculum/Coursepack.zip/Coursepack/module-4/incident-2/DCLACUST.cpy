      ******************************************************************
      * DCLGEN TABLE(SAV.ACCT_CUSTOMER)                                *
      *        LIBRARY(PROD.SAV.DCLGEN(DCLACUST))                      *
      *        LANGUAGE(COBOL) NAMES(ACUST-) QUOTE                     *
      * ... IS THE DCLGEN COMMAND THAT MADE THE FOLLOWING STATEMENTS   *
      *----------------------------------------------------------------*
      * USED BY: CUSTLINK  (BATCH, STATEMENT PREPARATION)              *
      *          ACINQ01   (CICS ONLINE ACCOUNT INQUIRY)               *
      *          CRMRECON  (BATCH, WEEKLY CRM RECONCILIATION)          *
      ******************************************************************
           EXEC SQL DECLARE SAV.ACCT_CUSTOMER TABLE
           ( ACCT_NUMBER                    CHAR(12) NOT NULL,
             HOLDER_SEQ                     SMALLINT NOT NULL,
             PRIMARY_HOLDER                 CHAR(1) NOT NULL,
             CUST_ID                        CHAR(10) NOT NULL,
             BRANCH_CODE                    CHAR(4) NOT NULL,
             STMT_DELIVERY                  CHAR(1) NOT NULL,
             LOAD_TS                        TIMESTAMP NOT NULL
           ) END-EXEC.
      ******************************************************************
      * COBOL DECLARATION FOR TABLE SAV.ACCT_CUSTOMER                  *
      ******************************************************************
       01  DCLACCT-CUSTOMER.
           10 ACUST-ACCT-NUMBER    PIC X(12).
           10 ACUST-HOLDER-SEQ     PIC S9(4) USAGE COMP.
           10 ACUST-PRIMARY-HOLDER PIC X(1).
           10 ACUST-CUST-ID        PIC X(10).
           10 ACUST-BRANCH-CODE    PIC X(4).
           10 ACUST-STMT-DELIVERY  PIC X(1).
           10 ACUST-LOAD-TS        PIC X(26).
      ******************************************************************
      * THE NUMBER OF COLUMNS DESCRIBED BY THIS DECLARATION IS 7       *
      ******************************************************************
