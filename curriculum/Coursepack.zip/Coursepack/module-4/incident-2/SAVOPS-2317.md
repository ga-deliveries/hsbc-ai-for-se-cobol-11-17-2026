# SAVOPS-2317: STMTPREP failing RC=16, SQLCODE -811 in CUSTLINK. November statements blocked

| Field | Value |
|---|---|
| Type | Incident |
| Priority | **P2: High** |
| Status | In Progress |
| Component | Savings batch / Statements |
| Reporter | Batch Operations (night shift) |
| Assignee | Savings SME on call |
| Created | Sun 1 Nov 2026 04:12 |
| Due | **Tue 3 Nov 2026 12:00**: monthly statements must be issued by the 3rd business day (regulatory) |
| Labels | `stmtprep` `custlink` `db2` `month-end` |

## Description
Job **STMTPREP** failed at step STEP010 (program CUSTLINK) at 03:58 with RC=16. CUSTLINK displayed `SQLCODE -811` for one account and stopped after reading 2,317 accounts.

Ops resubmitted STMTPREP at 04:05 with no changes. It failed the same way, at the same account.

**STMTMTH** (STMTGEN, monthly statements) depends on STMTPREP and is on hold. No statements have been produced.

## Ops notes
- 04:20: The night shift saw that **CRMLOAD** (CRM customer link load) ran twice on Saturday evening. The first run at 21:14 ended RC=08 in its image-copy step after a timeout, so the operator resubmitted the whole job at 22:02, which ended RC=00. Not sure if related.
- 04:35: DBA on call ran a query for the failing account. Output attached.
- 04:40: CICS account inquiry (ACINQ01) logged a handful of `SQLCODE -811` errors since Saturday night. Service desk has two customer complaints that "account details unavailable" in the branch app.

## Attachments
- `STMTPREP-joblog.txt`
- `CRMLOAD-joblog.txt` (both runs)
- `dba-query.txt`

## Acceptance criteria
1. Root cause identified, with evidence.
2. Impact assessed: every program and process affected, not just STMTPREP.
3. Recovery plan agreed so statements go out on time.
4. Permanent fix proposed and tested, with a change description ready for review.
