      *================================================================*
      * COPYBOOK : STMTXREC                                            *
      * PURPOSE  : MONTHLY STATEMENT EXTRACT RECORD (LRECL 50, FB)     *
      * DATASET  : PROD.SAV.STMTX.MONTHLY                              *
      * WRITTEN BY: CUSTLINK                                           *
      * READ BY   : STMTGEN (STATEMENT PRINT/EMAIL)                    *
      *             STMTARCH (STATEMENT ARCHIVE INDEX)                 *
      *----------------------------------------------------------------*
      * CHANGE LOG                                                     *
      * 2008-02-11  JKB  ORIGINAL                                      *
      * 2015-06-08  SNA  SX-STMT-DELIVERY ADDED FROM FILLER            *
      *================================================================*
       01  STMT-EXTRACT-REC.
           05  SX-ACCT-NUMBER           PIC X(12).
           05  SX-ACCT-TYPE             PIC X(02).
           05  SX-ACCT-STATUS           PIC X(01).
           05  SX-BALANCE               PIC S9(7)V99    COMP-3.
           05  SX-CUST-ID               PIC X(10).
           05  SX-BRANCH-CODE           PIC X(04).
           05  SX-STMT-DELIVERY         PIC X(01).
               88  SX-DELIVER-PAPER                VALUE 'P'.
               88  SX-DELIVER-EMAIL                VALUE 'E'.
           05  FILLER                   PIC X(15).
