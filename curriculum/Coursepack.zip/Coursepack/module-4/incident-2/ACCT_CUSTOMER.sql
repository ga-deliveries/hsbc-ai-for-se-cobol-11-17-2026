-- =================================================================
-- SAV.ACCT_CUSTOMER - links savings accounts to their customers
-- Loaded daily from the CRM system by job CRMLOAD (LOAD utility).
-- One row per account holder. Joint accounts have one row per
-- holder, and exactly one holder per account should have
-- PRIMARY_HOLDER = 'Y'.
-- =================================================================
CREATE TABLE SAV.ACCT_CUSTOMER
  ( ACCT_NUMBER      CHAR(12)    NOT NULL
  , HOLDER_SEQ       SMALLINT    NOT NULL
  , PRIMARY_HOLDER   CHAR(1)     NOT NULL
  , CUST_ID          CHAR(10)    NOT NULL
  , BRANCH_CODE      CHAR(4)     NOT NULL
  , STMT_DELIVERY    CHAR(1)     NOT NULL   -- 'P' paper, 'E' email
  , LOAD_TS          TIMESTAMP   NOT NULL   -- when CRMLOAD loaded the row
  )
  IN SAVDB.ACUSTTS;

-- Lookup index used by CUSTLINK and ACINQ01
CREATE INDEX SAV.ACI1 ON SAV.ACCT_CUSTOMER (ACCT_NUMBER);

-- 2019-03-18 CR-31877 (joint accounts): unique index SAV.ACI0 on
-- (ACCT_NUMBER, HOLDER_SEQ) dropped so the joint-account migration
-- could load holders in two passes. To be re-created after the
-- migration completes.
-- DROP INDEX SAV.ACI0;
