       IDENTIFICATION DIVISION.
       PROGRAM-ID.    CUSTLINK.
       AUTHOR.        J K BRENNAN.
       DATE-WRITTEN.  2008-02-11.
      *================================================================*
      * CUSTLINK - LINK SAVINGS ACCOUNTS TO THEIR PRIMARY CUSTOMER     *
      *            FOR MONTHLY STATEMENTS                              *
      *                                                                *
      * RUNS IN JOB STMTPREP, STEP010, AFTER MONTH-END INTEREST.       *
      * FOR EVERY ACCOUNT THAT IS NOT CLOSED, LOOKS UP THE PRIMARY     *
      * ACCOUNT HOLDER IN DB2 TABLE ACCT_CUSTOMER AND WRITES ONE       *
      * STATEMENT EXTRACT RECORD (STMTXREC). STMTGEN READS THE         *
      * EXTRACT TO PRODUCE STATEMENTS.                                 *
      *----------------------------------------------------------------*
      * CHANGE LOG                                                     *
      * 2008-02-11  JKB  ORIGINAL                                      *
      * 2015-06-08  SNA  STATEMENT DELIVERY PREFERENCE (PAPER/EMAIL)   *
      * 2019-03-18  RDM  CR-31877 JOINT ACCOUNTS - SELECT THE PRIMARY  *
      *                  HOLDER ONLY (PRIMARY_HOLDER = 'Y')            *
      *================================================================*
       ENVIRONMENT DIVISION.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           SELECT ACCT-IN-FILE   ASSIGN TO ACCTIN
                  FILE STATUS IS WS-ACCTIN-STATUS.
           SELECT STMT-EXTRACT   ASSIGN TO STMTX
                  FILE STATUS IS WS-STMTX-STATUS.
           SELECT EXCEPTION-FILE ASSIGN TO EXCPTN
                  FILE STATUS IS WS-EXCPTN-STATUS.

       DATA DIVISION.
       FILE SECTION.
       FD  ACCT-IN-FILE
           RECORDING MODE IS F.
           COPY ACCTREC.

       FD  STMT-EXTRACT
           RECORDING MODE IS F.
           COPY STMTXREC.

       FD  EXCEPTION-FILE
           RECORDING MODE IS F.
       01  EXCPTN-REC                   PIC X(80).

       WORKING-STORAGE SECTION.
           EXEC SQL INCLUDE SQLCA END-EXEC.
           EXEC SQL INCLUDE DCLACUST END-EXEC.

       01  WS-FILE-STATUSES.
           05  WS-ACCTIN-STATUS         PIC X(02).
           05  WS-STMTX-STATUS          PIC X(02).
           05  WS-EXCPTN-STATUS         PIC X(02).

       01  WS-SWITCHES.
           05  WS-ACCT-EOF-SW           PIC X(01)       VALUE 'N'.
               88  END-OF-ACCOUNTS                 VALUE 'Y'.

       01  WS-COUNTERS.
           05  WS-READ-CNT              PIC 9(07)       VALUE ZERO.
           05  WS-EXTRACT-CNT           PIC 9(07)       VALUE ZERO.
           05  WS-NOLINK-CNT            PIC 9(07)       VALUE ZERO.
           05  WS-CLOSED-CNT            PIC 9(07)       VALUE ZERO.

       01  WS-DISPLAY-SQLCODE           PIC -(8)9.

       01  WS-EXCEPTION-LINE.
           05  WS-EXC-ACCT-NUMBER       PIC X(12).
           05  FILLER                   PIC X(02)       VALUE SPACES.
           05  WS-EXC-MESSAGE           PIC X(50).
           05  FILLER                   PIC X(16)       VALUE SPACES.

       PROCEDURE DIVISION.
      *----------------------------------------------------------------*
       0000-MAIN.
           PERFORM 0100-INITIALISE
           PERFORM 1000-PROCESS-ACCOUNT
               UNTIL END-OF-ACCOUNTS
           PERFORM 9000-TERMINATE
           GOBACK.

      *----------------------------------------------------------------*
       0100-INITIALISE.
           OPEN INPUT  ACCT-IN-FILE
                OUTPUT STMT-EXTRACT
                       EXCEPTION-FILE
           IF WS-ACCTIN-STATUS NOT = '00'
              OR WS-STMTX-STATUS NOT = '00'
               DISPLAY 'CUSTLINK - OPEN FAILED. ACCTIN: '
                       WS-ACCTIN-STATUS ' STMTX: ' WS-STMTX-STATUS
               MOVE 16 TO RETURN-CODE
               STOP RUN
           END-IF
           PERFORM 8000-READ-ACCOUNT.

      *----------------------------------------------------------------*
       1000-PROCESS-ACCOUNT.
           IF ACCT-CLOSED
               ADD 1 TO WS-CLOSED-CNT
           ELSE
               PERFORM 2000-GET-PRIMARY-HOLDER
           END-IF
           PERFORM 8000-READ-ACCOUNT.

      *----------------------------------------------------------------*
       2000-GET-PRIMARY-HOLDER.
           EXEC SQL
               SELECT CUST_ID, BRANCH_CODE, STMT_DELIVERY
                 INTO :ACUST-CUST-ID,
                      :ACUST-BRANCH-CODE,
                      :ACUST-STMT-DELIVERY
                 FROM SAV.ACCT_CUSTOMER
                WHERE ACCT_NUMBER    = :ACCT-NUMBER
                  AND PRIMARY_HOLDER = 'Y'
           END-EXEC

           EVALUATE SQLCODE
               WHEN 0
                   PERFORM 3000-WRITE-EXTRACT
               WHEN 100
                   MOVE ACCT-NUMBER TO WS-EXC-ACCT-NUMBER
                   MOVE 'NO PRIMARY CUSTOMER LINK - NO STATEMENT'
                     TO WS-EXC-MESSAGE
                   WRITE EXCPTN-REC FROM WS-EXCEPTION-LINE
                   ADD 1 TO WS-NOLINK-CNT
               WHEN OTHER
                   MOVE SQLCODE TO WS-DISPLAY-SQLCODE
                   DISPLAY 'CUSTLINK - ACCT_CUSTOMER SQLCODE '
                           WS-DISPLAY-SQLCODE
                           ' FOR ACCOUNT ' ACCT-NUMBER
                   DISPLAY 'CUSTLINK - ACCOUNTS READ    : '
                           WS-READ-CNT
                   DISPLAY 'CUSTLINK - EXTRACTS WRITTEN : '
                           WS-EXTRACT-CNT
                   MOVE 16 TO RETURN-CODE
                   STOP RUN
           END-EVALUATE.

      *----------------------------------------------------------------*
       3000-WRITE-EXTRACT.
           MOVE ACCT-NUMBER          TO SX-ACCT-NUMBER
           MOVE ACCT-TYPE            TO SX-ACCT-TYPE
           MOVE ACCT-STATUS          TO SX-ACCT-STATUS
           MOVE ACCT-BALANCE         TO SX-BALANCE
           MOVE ACUST-CUST-ID        TO SX-CUST-ID
           MOVE ACUST-BRANCH-CODE    TO SX-BRANCH-CODE
           MOVE ACUST-STMT-DELIVERY  TO SX-STMT-DELIVERY
           WRITE STMT-EXTRACT-REC
           ADD 1 TO WS-EXTRACT-CNT.

      *----------------------------------------------------------------*
       8000-READ-ACCOUNT.
           READ ACCT-IN-FILE
               AT END
                   SET END-OF-ACCOUNTS TO TRUE
               NOT AT END
                   ADD 1 TO WS-READ-CNT
           END-READ.

      *----------------------------------------------------------------*
       9000-TERMINATE.
           DISPLAY 'CUSTLINK - ACCOUNTS READ    : ' WS-READ-CNT
           DISPLAY 'CUSTLINK - EXTRACTS WRITTEN : ' WS-EXTRACT-CNT
           DISPLAY 'CUSTLINK - NO CUSTOMER LINK : ' WS-NOLINK-CNT
           DISPLAY 'CUSTLINK - CLOSED, SKIPPED  : ' WS-CLOSED-CNT
           CLOSE ACCT-IN-FILE
                 STMT-EXTRACT
                 EXCEPTION-FILE.
