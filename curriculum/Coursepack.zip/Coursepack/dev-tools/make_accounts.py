"""Generate the Module 2 synthetic account master: data/ACCTIN-5000.dat (5,000 records).

Deterministic (fixed seed), so every build of the course pack gets the same file
and the same harness report. Build-team tool, not part of the learner pack.

Contents
  4,988 ordinary accounts 710000000001-710000004988. Interest was last capitalised
        at the September month-end (ACCT-LAST-INT-DATE 20260930), so accrued interest
        is 29 days' worth (1-29 October).
  12 accounts 720000000101-720000000112, migrated on 2026-10-01 from an acquired
        private bank. Its platform capitalised interest once a year; these accounts
        were last capitalised on 31 January 2026, and the migration carried their
        accrued interest and last-interest date across unchanged. Their accrued
        interest is exactly 271 days' worth (1 February - 29 October) at the
        current rates: 271 x the truncated daily interest.

Planted cases (the Lab's "unexplained differences") - the three largest migrated
balances, where 271 days of interest brings ACCT-ACCRUED-INT (PIC S9(5)V9(4),
max 99,999.9999) to the edge of the field on the night of 30 October:
  720000000104  DOWN : old rate's day fits, new rate's day overflows -> the day is
                       not added (rule 9), so interest goes DOWN with the change.
  720000000109  SAME : day overflows in both versions -> identical output,
  720000000111  SAME   though the account is in the expected-change rule.
"""
import os, random, sys
from decimal import Decimal, ROUND_DOWN

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "module-2", "harness"))
from acctrec import pack_record

TIERS = [(0, Decimal("0.50")), (1000, Decimal("1.25")), (10000, Decimal("2.27")), (50000, Decimal("3.12"))]
Q4 = Decimal("0.0001")
MIGRATED_DAYS = 271  # 1 Feb - 29 Oct 2026

# Migrated private-bank accounts: number -> balance. 104, 109 and 111 are the planted cases.
MIGRATED = {
    "720000000101": "1875400.00", "720000000102": "642980.55", "720000000103": "2950000.00",
    "720000000104": "4300986.40", "720000000105": "318760.12", "720000000106": "87450.00",
    "720000000107": "1204330.75", "720000000108": "3610250.00", "720000000109": "4312450.18",
    "720000000110": "755000.00", "720000000111": "4308715.92", "720000000112": "2245890.30",
}


def rate_for(bal, status):
    if status == "D":
        return TIERS[0][1]
    r = TIERS[0][1]
    for floor, rate in TIERS:
        if bal >= floor:
            r = rate
    return r


def daily(bal, rate):
    return (bal * rate / 100 / 365).quantize(Q4, rounding=ROUND_DOWN)


def main():
    rnd = random.Random(20261030)
    rows = []
    for i in range(1, 4989):
        acct = f"7100{i:08d}"
        status = rnd.choices("ACDFL", weights=[85, 4, 5, 4, 2])[0]
        typ = "BS" if rnd.random() < 0.25 else "SV"
        bonus = "Y" if typ == "BS" and rnd.random() < 0.8 else "N"
        wd = 0 if rnd.random() < 0.55 else rnd.randint(1, 8)
        u = rnd.random()
        if u < 0.02:
            bal = Decimal("0.00")
        elif u < 0.04:
            bal = -Decimal(rnd.randint(1, 50000)) / 100
        else:
            bal = Decimal(str(round(min(rnd.lognormvariate(8.7, 1.3), 2500000), 2))).quantize(Decimal("0.01"))
        acc = Decimal("0")
        if bal > 0 and status not in ("C", "F", "L"):
            rate = rate_for(bal, status)
            if typ == "BS" and bonus == "Y" and wd == 0:
                rate += Decimal("0.50")
            acc = daily(bal, rate) * 29
        rows.append({"ACCT-NUMBER": acct, "ACCT-TYPE": typ, "ACCT-STATUS": status,
                     "ACCT-BALANCE": f"{bal:.2f}", "ACCT-ACCRUED-INT": f"{acc:.4f}",
                     "ACCT-LAST-INT-DATE": "20260930", "ACCT-BONUS-FLAG": bonus,
                     "ACCT-WITHDRAWALS-MTD": str(wd)})
    for acct, b in MIGRATED.items():
        bal = Decimal(b)
        acc = daily(bal, rate_for(bal, "A")) * MIGRATED_DAYS
        rows.append({"ACCT-NUMBER": acct, "ACCT-TYPE": "SV", "ACCT-STATUS": "A",
                     "ACCT-BALANCE": f"{bal:.2f}", "ACCT-ACCRUED-INT": f"{acc:.4f}",
                     "ACCT-LAST-INT-DATE": "20260131", "ACCT-BONUS-FLAG": "N",
                     "ACCT-WITHDRAWALS-MTD": str(rnd.randint(0, 2))})
    out = os.path.join(ROOT, "module-2", "data", "ACCTIN-5000.dat")
    open(out, "wb").write(b"".join(pack_record(r) for r in rows))
    print(f"Wrote {len(rows)} records to {out}")


if __name__ == "__main__":
    main()
