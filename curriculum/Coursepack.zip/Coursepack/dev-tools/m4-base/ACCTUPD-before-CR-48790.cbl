       IDENTIFICATION DIVISION.
       PROGRAM-ID.    ACCTUPD.
       AUTHOR.        K P MORRIS.
       DATE-WRITTEN.  1995-08-07.
      *================================================================*
      * ACCTUPD - DAILY ACCOUNT MASTER MAINTENANCE, SAVINGS            *
      *                                                                *
      * RUNS IN JOB ACCTDLY, STEP010, EVERY NIGHT BEFORE EODINT.       *
      * COPIES THE ACCOUNT MASTER TO A NEW GENERATION, APPLYING THE    *
      * DAY'S STATUS CHANGES (FREEZE, CLOSE, DORMANT, REACTIVATE).     *
      * NEW ACCOUNTS ARE ADDED AT THE END OF THE FILE; EODINT SORTS    *
      * THE MASTER BEFORE INTEREST IS CALCULATED.                      *
      *----------------------------------------------------------------*
      * CHANGE LOG                                                     *
      * 1995-08-07  KPM  ORIGINAL                                      *
      * 1998-11-02  KPM  Y2K REVIEW - NO DATE FIELDS CHANGED           *
      * 2013-09-30  SNA  LEGAL HOLD STATUS 'L' ACCEPTED                *
      *================================================================*
       ENVIRONMENT DIVISION.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           SELECT ACCT-IN-FILE    ASSIGN TO ACCTIN
                  FILE STATUS IS WS-ACCTIN-STATUS.
           SELECT STATUS-CHG-FILE ASSIGN TO STATCHG
                  FILE STATUS IS WS-STATCHG-STATUS.
           SELECT ACCT-OUT-FILE   ASSIGN TO ACCTOUT
                  FILE STATUS IS WS-ACCTOUT-STATUS.

       DATA DIVISION.
       FILE SECTION.
       FD  ACCT-IN-FILE
           RECORDING MODE IS F.
       01  ACCT-IN-REC                  PIC X(100).

       FD  STATUS-CHG-FILE
           RECORDING MODE IS F.
       01  STATUS-CHG-REC.
           05  SC-ACCT-NUMBER           PIC X(12).
           05  SC-NEW-STATUS            PIC X(01).
           05  FILLER                   PIC X(67).

       FD  ACCT-OUT-FILE
           RECORDING MODE IS F.
       01  ACCT-OUT-REC                 PIC X(100).

       WORKING-STORAGE SECTION.
       01  WS-FILE-STATUSES.
           05  WS-ACCTIN-STATUS         PIC X(02).
           05  WS-STATCHG-STATUS        PIC X(02).
           05  WS-ACCTOUT-STATUS        PIC X(02).

       01  WS-SWITCHES.
           05  WS-MASTER-EOF-SW         PIC X(01)       VALUE 'N'.
               88  END-OF-MASTER                   VALUE 'Y'.
           05  WS-STATCHG-EOF-SW        PIC X(01)       VALUE 'N'.
               88  END-OF-STATUS-CHANGES           VALUE 'Y'.

       01  WS-COUNTERS.
           05  WS-READ-CNT              PIC 9(07)       VALUE ZERO.
           05  WS-CHANGED-CNT           PIC 9(07)       VALUE ZERO.
           05  WS-WRITTEN-CNT           PIC 9(07)       VALUE ZERO.

       01  WS-STATUS-CHANGES.
           05  WS-SC-COUNT              PIC 9(03)       VALUE ZERO.
           05  WS-SC-ENTRY              OCCURS 500 TIMES
                                        INDEXED BY WS-SC-IDX.
               10  WS-SC-ACCT-NUMBER    PIC X(12).
               10  WS-SC-NEW-STATUS     PIC X(01).

           COPY ACCTREC.

       PROCEDURE DIVISION.
      *----------------------------------------------------------------*
       0000-MAIN.
           PERFORM 0100-INITIALISE
           PERFORM 1000-COPY-MASTER
               UNTIL END-OF-MASTER
           PERFORM 9000-TERMINATE
           GOBACK.

      *----------------------------------------------------------------*
       0100-INITIALISE.
           OPEN INPUT  ACCT-IN-FILE
                       STATUS-CHG-FILE
                OUTPUT ACCT-OUT-FILE
           IF WS-ACCTIN-STATUS NOT = '00'
               DISPLAY 'ACCTUPD - OPEN FAILED. ACCTIN: '
                       WS-ACCTIN-STATUS
               MOVE 16 TO RETURN-CODE
               STOP RUN
           END-IF

           PERFORM 0200-LOAD-STATUS-CHANGES
               UNTIL END-OF-STATUS-CHANGES
           PERFORM 8000-READ-MASTER.

      *----------------------------------------------------------------*
       0200-LOAD-STATUS-CHANGES.
           READ STATUS-CHG-FILE
               AT END
                   SET END-OF-STATUS-CHANGES TO TRUE
               NOT AT END
                   ADD 1 TO WS-SC-COUNT
                   MOVE SC-ACCT-NUMBER
                     TO WS-SC-ACCT-NUMBER (WS-SC-COUNT)
                   MOVE SC-NEW-STATUS
                     TO WS-SC-NEW-STATUS (WS-SC-COUNT)
           END-READ.

      *----------------------------------------------------------------*
       1000-COPY-MASTER.
           PERFORM 1100-APPLY-STATUS-CHANGE
           WRITE ACCT-OUT-REC FROM ACCT-REC
           ADD 1 TO WS-WRITTEN-CNT
           PERFORM 8000-READ-MASTER.

      *----------------------------------------------------------------*
       1100-APPLY-STATUS-CHANGE.
           SET WS-SC-IDX TO 1
           SEARCH WS-SC-ENTRY
               AT END
                   CONTINUE
               WHEN WS-SC-IDX > WS-SC-COUNT
                   CONTINUE
               WHEN WS-SC-ACCT-NUMBER (WS-SC-IDX) = ACCT-NUMBER
                   MOVE WS-SC-NEW-STATUS (WS-SC-IDX) TO ACCT-STATUS
                   ADD 1 TO WS-CHANGED-CNT
           END-SEARCH.

      *----------------------------------------------------------------*
       8000-READ-MASTER.
           READ ACCT-IN-FILE INTO ACCT-REC
               AT END
                   SET END-OF-MASTER TO TRUE
               NOT AT END
                   ADD 1 TO WS-READ-CNT
           END-READ.

      *----------------------------------------------------------------*
       9000-TERMINATE.
           DISPLAY 'ACCTUPD - MASTER RECORDS READ     : ' WS-READ-CNT
           DISPLAY 'ACCTUPD - STATUS CHANGES APPLIED  : ' WS-CHANGED-CNT
           DISPLAY 'ACCTUPD - RECORDS WRITTEN         : ' WS-WRITTEN-CNT
           CLOSE ACCT-IN-FILE
                 STATUS-CHG-FILE
                 NEWACCT-FILE
                 ACCT-OUT-FILE.
