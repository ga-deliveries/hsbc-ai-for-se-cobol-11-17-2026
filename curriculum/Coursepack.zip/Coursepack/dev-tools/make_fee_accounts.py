"""Generate the Module 3 month-end account master: module-3/data/ACCTMAST-20261031.dat.

1,500 accounts as they stand when FEEMTH runs on 31 October 2026, before EODINT's
month-end capitalisation: interest last capitalised 30 September, withdrawals
counted for October. Deterministic (fixed seed). Build-team tool.

Nothing is planted in the data. The defect is in FEEASSES-v2 (the lost
PERFORM ... THRU fall-through into 2050-APPLY-FEE-CAP); the data simply has a
realistic number of low-balance, high-withdrawal accounts for it to show up on.
"""
import os, random, sys
from decimal import Decimal, ROUND_DOWN

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "module-2", "harness"))
from acctrec import pack_record

TIERS = [(0, Decimal("0.50")), (1000, Decimal("1.25")), (10000, Decimal("2.27")), (50000, Decimal("3.12"))]


def rate_for(bal, status):
    if status == "D":
        return TIERS[0][1]
    r = TIERS[0][1]
    for floor, rate in TIERS:
        if bal >= floor:
            r = rate
    return r


def main():
    rnd = random.Random(20261031)
    rows = []
    for i in range(1, 1501):
        acct = f"7100{i * 3 + 7:08d}"
        status = rnd.choices("ACDFL", weights=[86, 3, 5, 4, 2])[0]
        typ = "BS" if rnd.random() < 0.25 else "SV"
        bonus = "Y" if typ == "BS" and rnd.random() < 0.8 else "N"
        wd = rnd.choices([0, rnd.randint(1, 3), rnd.randint(4, 6), rnd.randint(7, 12)],
                         weights=[45, 30, 15, 10])[0]
        u = rnd.random()
        if u < 0.02:
            bal = Decimal("0.00")
        elif u < 0.04:
            bal = -Decimal(rnd.randint(1, 30000)) / 100
        else:
            bal = Decimal(str(round(min(rnd.lognormvariate(7.7, 1.5), 900000), 2))).quantize(Decimal("0.01"))
        acc = Decimal("0")
        if bal > 0 and status not in ("C", "F", "L"):
            rate = rate_for(bal, status)
            if typ == "BS" and bonus == "Y" and wd == 0:
                rate += Decimal("0.50")
            acc = (bal * rate / 100 / 365).quantize(Decimal("0.0001"), rounding=ROUND_DOWN) * 30
        rows.append({"ACCT-NUMBER": acct, "ACCT-TYPE": typ, "ACCT-STATUS": status,
                     "ACCT-BALANCE": f"{bal:.2f}", "ACCT-ACCRUED-INT": f"{acc:.4f}",
                     "ACCT-LAST-INT-DATE": "20260930", "ACCT-BONUS-FLAG": bonus,
                     "ACCT-WITHDRAWALS-MTD": str(wd)})
    out = os.path.join(ROOT, "module-3", "data", "ACCTMAST-20261031.dat")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    open(out, "wb").write(b"".join(pack_record(r) for r in rows))
    print(f"Wrote {len(rows)} records to {out}")


if __name__ == "__main__":
    main()
