# Course pack build notes (Modules 1 to 4)

These notes are for the dev team and the Skillable build. They aren't part of the learner pack.

## Layout

```
module-1/          learner files for Module 1 (program, copybooks, JCL)
module-2/          learner files for Module 2
  data/ACCTIN-5000.dat   5,000 synthetic accounts, 100-byte records (packed fields)
  harness/               pack-records, run-regression, PARMDRV.cbl, acctrec.py
  demo.csv               4 records for the I Do packing demo (never added to a run)
module-3/          learner files for Module 3 (FEEASSES, DB2 stand-in harness)
module-4/          learner files for Module 4 (src, incident evidence, .github)
labs/              the four lab handouts (You Do), kept OUT of the module folders
facilitator/       answer keys - keep OFF learner VMs
dev-tools/         make_accounts.py, make_fee_accounts.py, m4-base, this file
dev-verification/  Module 1 rule checks (verify.py)
```

## Lab handouts live in `labs/`, not in the module folders
Copilot reads any file in the open folder, even in Ask mode and even when it isn't attached. With a handout inside `module-4`, a test run took the scenario clock and the night shift's theory from the handout, hints included. Keep the handouts in `labs/`. Learners read them on the GA platform, or open `labs/` in a second VS Code window, never in the module workspace.

## VM requirements
The Skillable image is **Ubuntu + VS Code** (agreed 28 October; there is no Windows or IDz build).
- **Python 3**, as `python3` (preinstalled on Ubuntu). Standard library only.
- **GnuCOBOL** from the Ubuntu `gnucobol` package, so `cobc` is on PATH. The harness compiles with `cobc -std=ibm`.
- **VS Code** with GitHub Copilot, GitHub Copilot Chat, IBM Z Open Editor (plus `openjdk-21-jre-headless`). Mermaid diagrams render in the Markdown preview with VS Code's built-in Mermaid support (tested 7 Nov 2026 in the Skillable Ubuntu lab); add Markdown Preview Mermaid Support only if that test fails. See the VS Code section below.
- Launch routes are VS Code Run Task (`.vscode/tasks.json`) or the `.sh` scripts. The `tasks.json` files still carry `windows` entries for local testing on a Windows PC; they're unused on the image.

## How the harness stands in for z/OS
- **DD names:** GnuCOBOL resolves `ASSIGN TO ACCTIN` through the `DD_ACCTIN` environment variable. The harness sets `DD_ACCTIN`, `DD_RATEIN`, `DD_ACCTOUT` and `DD_EXCPTN` per run, which does the job of the EODINT DD statements.
- **EXEC PARM:** `PARMDRV.cbl` passes the command-line PARM as a halfword length plus data to `INTCALC`'s `LK-PARM`, as z/OS does.
- **Same member name, two versions:** both programs say `COPY RATETIER.`. The harness compiles each against its own copy directory, with `RATETIER.cpy` for the original and `RATETIER-v2.cpy` for the modified version, the way two different PDS libraries would on z/OS.
- **Rate file:** 80-byte records. Floor is `9(05)` in whole units. Rate is `9(02)V99` for the current layout and `9(02)V999` for the new one, with FILLER 71 / 70. They're built from `rates-current.csv` and `rates-new.csv` at run time.
- **Character set:** files are ASCII, not EBCDIC. Packed fields are identical. The only visible difference is the sort order of letters vs digits (the `BND` records sort after `7100...` here, before them on z/OS).

## Module 3: DB2 stand-in
- FEEASSES uses embedded SQL, which GnuCOBOL can't run on its own. At compile time, `module-3/harness/run-regression.py` copies each program to `harness/work/` and rewrites every `EXEC SQL ... END-EXEC` block as a `CALL` to `SQLFSCH` (the FEE_SCHEDULE select) or `SQLFHIS` (the FEE_HISTORY insert) in `SQLSTUB.cbl`. Host variables are passed in the order they appear in the statement. `EXEC SQL INCLUDE SQLCA` becomes an `01 SQLCA` with `SQLCODE PIC S9(9) COMP-5`. Learners never see the rewritten copies.
- FEE_SCHEDULE rows come from `harness/fee-schedule.csv`, which must match the inserts in `FEE_TABLES.sql`. FEE_HISTORY rows go to `work/FEEHIST-*.dat`.
- `PARMDRV.cbl` passes the real PARM length, so `2026-10-31` (10 bytes) and `2026-10-31,OVRD2219` (19 bytes, the ops override) both behave as on z/OS.
- `facilitator/module-3/loop-demo/` holds the I Do Demo C program (`LOOPDEMO.cbl`, both versions of the sum loop) and `run-loop-demo.sh`, which compiles it with `cobc -std=ibm` and prints a four-row table (count 0 is the only DIFFERENT row). Instructor machine only; it needs nothing beyond GnuCOBOL.
- `dev-tools/make_fee_accounts.py` regenerates `module-3/data/ACCTMAST-20261031.dat` (1,500 accounts, seeded). There's no planted data. The defect is in FEEASSES-v2.

## Planted data (do not "fix")
`make_accounts.py` creates 12 accounts (`720000000101` to `720000000112`) migrated from an acquired private bank that capitalised annually, each with 271 days of accrued interest. Three of them, `720000000104`, `720000000109` and `720000000111`, are the cases the Lab investigates. See `facilitator/module-2/unexplained-differences-key.md`. The generator is seeded, so regenerating gives byte-identical data.

## Module 4
- `module-4/src/INTCALC.cbl` and `RATETIER.cpy` are the Module 2 **v2** versions (as deployed with CR-48812). `FEEASSES.cbl` is the Module 3 original. All three must stay identical to those modules.
- `ACCTUPD-CR-48790.diff` is a real `diff -u` between `dev-tools/m4-base/ACCTUPD-before-CR-48790.cbl` and `module-4/src/ACCTUPD.cbl`. Regenerate it if either file changes.
- The incident-1 evidence files (job log, CEEDUMP, listing excerpt) are hand-built to show **z/OS** behaviour. Statement 142 is mapped to source line 164. If `INTCALC.cbl` changes, recheck the listing excerpt's line numbers.
- Incident 2 (`CUSTLINK`, SQLCODE -811) is evidence and code for reading only. There's no harness, and it isn't compiled for learners.
- `.github/copilot-instructions.md` and `incident-playbook.md` ship empty. Learners fill them in. VS Code shows dot-folders by default; check nothing on the image hides `.github` or `.vscode`.

## GnuCOBOL versions: 3.1.2 and 3.2 both supported
- **GnuCOBOL 3.2 truncates instead of rounding in `ADD ... ROUNDED`.** Confirmed on 3.2.0: `ADD 0.0060 TO 100.00 ROUNDED` gives 100.00, and `ADD 0.0050 TO 100.01 ROUNDED` gives 100.01. `COMPUTE ... ROUNDED` and `ROUNDED MODE IS NEAREST-AWAY-FROM-ZERO` are correct. GnuCOBOL 3.1.2 and IBM Enterprise COBOL are correct in all cases.
- **The course pack avoids it:** INTCALC's month-end capitalisation uses `COMPUTE ACCT-BALANCE ROUNDED = ACCT-BALANCE + ACCT-ACCRUED-INT`, which is the same behaviour on z/OS. Don't write `ADD ... ROUNDED` in any program the harness runs.
- **Which version you get:** Ubuntu 24.04 installs 3.1.2. Newer Ubuntu releases install 3.2. Run the acceptance tests on whichever version the image has.

## VS Code (the Skillable image, or WSL for local testing)
- **Copybook settings:** each module folder has a `zapp.yaml` for IBM Z Open Editor, pointing at that module's copybooks. Module 4 points at `src` and `incident-2`. Learners open **one module folder at a time** (File > Open Folder > `module-1`, and so on). The root `zapp.yaml` is for opening the whole pack (facilitator or testing). It searches `module-1` first, so `COPY RATETIER` finds the original 2-decimal version.
- **Harness tasks:** `module-2/.vscode/tasks.json` and `module-3/.vscode/tasks.json` give learners **Terminal > Run Task** entries for every harness run. Ctrl+Shift+B runs the Lab run. The root `.vscode/tasks.json` has the same tasks, prefixed by module, for whole-pack use. Tasks call `python3`.
- **Terminal launchers:** `harness/run-regression.sh` and `harness/pack-records.sh` work from any folder.
- **Fixed:** the harness compiles each version from its own private copybook folder. cobc searches the current folder for copybooks first, so starting the Module 2 harness from `module-2` (as a VS Code task does) used to compile INTCALC-v2 with the original `RATETIER.cpy`. That gave 0 expected changes and 1,473 unexplained. Every launch route now gives the same results.
- **Image setup found during local testing:**
  - IBM Z Open Editor needs **Java 21 or newer**, installed on the Linux side (`openjdk-21-jre-headless`). If it isn't found, set `zopeneditor.JAVA_HOME` to `/usr/lib/jvm/java-21-openjdk-amd64`.
  - VS Code opens new folders in **Restricted Mode**, which disables Z Open Editor. Pre-trust the course folders on the image, or turn off workspace trust there (`security.workspace.trust.enabled: false`).
  - Copilot must be signed in with an account whose seat has **Claude models enabled**. A Copilot Free account only offers "Auto", and shows "Upgrade" next to Claude.
  - Zowe Explorer may be installed alongside Z Open Editor and show "No Zowe CLI profile found". It's harmless, and isn't needed for this course.
