      *================================================================*
      * COPYBOOK : ACCTREC                                             *
      * PURPOSE  : SAVINGS ACCOUNT MASTER RECORD (LRECL 100, FB)       *
      * DATASET  : PROD.SAV.ACCTMAST (GDG)                             *
      * USED BY  : INTCALC, STMTGEN, FEEASSES, ACCTUPD                 *
      *----------------------------------------------------------------*
      * CHANGE LOG                                                     *
      * 1994-03-14  RJT  ORIGINAL LAYOUT                               *
      * 1998-11-02  KPM  Y2K - LAST-INT-DATE EXPANDED TO CCYYMMDD      *
      * 2004-06-21  DLW  BONUS SAVER PRODUCT - TYPE 'BS', BONUS FLAG   *
      * 2011-02-07  DLW  STUDENT SAVER (TYPE 'ST') WITHDRAWN           *
      * 2013-09-30  SNA  LEGAL HOLD STATUS 'L' ADDED TO ACCT-FROZEN    *
      * 2016-04-11  SNA  WITHDRAWALS-MTD ADDED FROM FILLER             *
      *================================================================*
       01  ACCT-REC.
           05  ACCT-NUMBER              PIC X(12).
           05  ACCT-TYPE                PIC X(02).
               88  ACCT-TYPE-SAVINGS               VALUE 'SV'.
               88  ACCT-TYPE-BONUS-SAVER           VALUE 'BS'.
           05  ACCT-STATUS              PIC X(01).
               88  ACCT-ACTIVE                     VALUE 'A'.
               88  ACCT-CLOSED                     VALUE 'C'.
               88  ACCT-FROZEN                     VALUE 'F' 'L'.
               88  ACCT-DORMANT                    VALUE 'D'.
           05  ACCT-BALANCE             PIC S9(7)V99    COMP-3.
           05  ACCT-ACCRUED-INT         PIC S9(5)V9(4)  COMP-3.
           05  ACCT-LAST-INT-DATE       PIC 9(08).
           05  ACCT-BONUS-FLAG          PIC X(01).
               88  ACCT-BONUS-ELIGIBLE             VALUE 'Y'.
           05  ACCT-WITHDRAWALS-MTD     PIC 9(03).
           05  FILLER                   PIC X(63).
