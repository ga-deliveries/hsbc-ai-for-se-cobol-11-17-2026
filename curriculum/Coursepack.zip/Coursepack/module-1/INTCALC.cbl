       IDENTIFICATION DIVISION.
       PROGRAM-ID.    INTCALC.
       AUTHOR.        R J THORNE.
       DATE-WRITTEN.  1994-03-14.
      *================================================================*
      * INTCALC - END-OF-DAY INTEREST ACCRUAL, SAVINGS ACCOUNTS        *
      *                                                                *
      * RUNS IN JOB EODINT, STEP030, EVERY NIGHT.                      *
      * READS THE SORTED ACCOUNT MASTER, ACCRUES ONE DAY OF INTEREST   *
      * PER ACCOUNT AND WRITES THE NEW GENERATION OF THE MASTER.       *
      * ON MONTH-END RUNS, ACCRUED INTEREST IS CAPITALISED.            *
      * DAILY INTEREST IS ROUNDED TO 4 DECIMAL PLACES.                 *
      *                                                                *
      * PARM: CCYYMMDD,X  - RUN DATE, MONTH-END SWITCH (Y/N)           *
      *----------------------------------------------------------------*
      * CHANGE LOG                                                     *
      * 1994-03-14  RJT  ORIGINAL                                      *
      * 1998-11-02  KPM  Y2K - RUN DATE TAKEN FROM PARM AS CCYYMMDD    *
      * 2004-06-21  DLW  BONUS SAVER - BONUS RATE FOR NO WITHDRAWALS   *
      * 2009-01-12  KPM  4TH RATE TIER                                 *
      * 2013-09-30  SNA  LEGAL HOLD - SEE ACCT-FROZEN IN ACCTREC       *
      * 2016-04-11  SNA  WITHDRAWAL COUNT RESET AT MONTH END           *
      *================================================================*
       ENVIRONMENT DIVISION.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           SELECT ACCT-IN-FILE   ASSIGN TO ACCTIN
                  FILE STATUS IS WS-ACCTIN-STATUS.
           SELECT RATE-FILE      ASSIGN TO RATEIN
                  FILE STATUS IS WS-RATE-STATUS.
           SELECT ACCT-OUT-FILE  ASSIGN TO ACCTOUT
                  FILE STATUS IS WS-ACCTOUT-STATUS.
           SELECT EXCEPTION-FILE ASSIGN TO EXCPTN.

       DATA DIVISION.
       FILE SECTION.
       FD  ACCT-IN-FILE
           RECORDING MODE IS F.
           COPY ACCTREC.

       FD  RATE-FILE
           RECORDING MODE IS F.
       01  RATE-IN-REC.
           05  RI-TIER-FLOOR            PIC 9(05).
           05  RI-TIER-RATE-PCT         PIC 9(02)V99.
           05  FILLER                   PIC X(71).

       FD  ACCT-OUT-FILE
           RECORDING MODE IS F.
       01  ACCT-OUT-REC                 PIC X(100).

       FD  EXCEPTION-FILE
           RECORDING MODE IS F.
       01  EXCPTN-REC                   PIC X(80).

       WORKING-STORAGE SECTION.
       01  WS-FILE-STATUSES.
           05  WS-ACCTIN-STATUS         PIC X(02).
           05  WS-RATE-STATUS           PIC X(02).
           05  WS-ACCTOUT-STATUS        PIC X(02).

       01  WS-SWITCHES.
           05  WS-ACCT-EOF-SW           PIC X(01)       VALUE 'N'.
               88  END-OF-ACCOUNTS                 VALUE 'Y'.
           05  WS-RATE-EOF-SW           PIC X(01)       VALUE 'N'.
               88  RATE-EOF                        VALUE 'Y'.
           05  WS-TIER-FOUND-SW         PIC X(01)       VALUE 'N'.
               88  TIER-FOUND                      VALUE 'Y'.
               88  TIER-NOT-FOUND                  VALUE 'N'.

       01  WS-COUNTERS.
           05  WS-READ-CNT              PIC 9(07)       VALUE ZERO.
           05  WS-WRITTEN-CNT           PIC 9(07)       VALUE ZERO.
           05  WS-ACCRUED-CNT           PIC 9(07)       VALUE ZERO.
           05  WS-CAPITALISED-CNT       PIC 9(07)       VALUE ZERO.
           05  WS-EXCEPTION-CNT         PIC 9(07)       VALUE ZERO.

       01  WS-WORK-FIELDS.
           05  WS-RUN-YEAR              PIC 9(04).
           05  WS-YEAR-QUOTIENT         PIC 9(04).
           05  WS-YEAR-REMAINDER        PIC 9(01).
           05  WS-DAYS-IN-YEAR          PIC 9(03).
           05  WS-TIER-IDX              PIC S9(02)      COMP.
           05  WS-APPLIED-RATE          PIC 9(02)V99.
           05  WS-DAILY-INT             PIC S9(05)V9(4).

       01  WS-EXCEPTION-LINE.
           05  WS-EXC-ACCT-NUMBER       PIC X(12).
           05  FILLER                   PIC X(02)       VALUE SPACES.
           05  WS-EXC-MESSAGE           PIC X(50).
           05  FILLER                   PIC X(16)       VALUE SPACES.

           COPY RATETIER.

       LINKAGE SECTION.
       01  LK-PARM.
           05  LK-PARM-LENGTH           PIC S9(04)      COMP.
           05  LK-PARM-DATA.
               10  LK-RUN-DATE          PIC 9(08).
               10  FILLER               PIC X(01).
               10  LK-MONTH-END-SW      PIC X(01).
                   88  LK-MONTH-END                VALUE 'Y'.

       PROCEDURE DIVISION USING LK-PARM.
      *----------------------------------------------------------------*
       0000-MAIN.
           PERFORM 0100-INITIALISE
           PERFORM 1000-PROCESS-ACCOUNT
               UNTIL END-OF-ACCOUNTS
           PERFORM 9000-TERMINATE
           GOBACK.

      *----------------------------------------------------------------*
       0100-INITIALISE.
           OPEN INPUT  ACCT-IN-FILE
                       RATE-FILE
                OUTPUT ACCT-OUT-FILE
                       EXCEPTION-FILE
           IF WS-ACCTIN-STATUS NOT = '00'
              OR WS-RATE-STATUS NOT = '00'
               DISPLAY 'INTCALC - OPEN FAILED. ACCTIN: '
                       WS-ACCTIN-STATUS ' RATEIN: ' WS-RATE-STATUS
               MOVE 16 TO RETURN-CODE
               STOP RUN
           END-IF

           MOVE LK-RUN-DATE (1:4) TO WS-RUN-YEAR
           DIVIDE WS-RUN-YEAR BY 4 GIVING WS-YEAR-QUOTIENT
               REMAINDER WS-YEAR-REMAINDER
           IF WS-YEAR-REMAINDER = ZERO
               MOVE 366 TO WS-DAYS-IN-YEAR
           ELSE
               MOVE 365 TO WS-DAYS-IN-YEAR
           END-IF

           PERFORM 0200-LOAD-RATE-TABLE
               UNTIL RATE-EOF
                  OR RT-TIER-COUNT = 4

           PERFORM 8000-READ-ACCOUNT.

      *----------------------------------------------------------------*
       0200-LOAD-RATE-TABLE.
           READ RATE-FILE
               AT END
                   SET RATE-EOF TO TRUE
               NOT AT END
                   ADD 1 TO RT-TIER-COUNT
                   MOVE RI-TIER-FLOOR
                     TO RT-TIER-FLOOR (RT-TIER-COUNT)
                   MOVE RI-TIER-RATE-PCT
                     TO RT-TIER-RATE (RT-TIER-COUNT)
           END-READ.

      *----------------------------------------------------------------*
       1000-PROCESS-ACCOUNT.
           EVALUATE TRUE
               WHEN ACCT-CLOSED
                   CONTINUE
               WHEN ACCT-FROZEN
                   MOVE 'FROZEN - NO ACCRUAL' TO WS-EXC-MESSAGE
                   PERFORM 7000-WRITE-EXCEPTION
               WHEN ACCT-BALANCE NOT > ZERO
                   CONTINUE
               WHEN OTHER
                   PERFORM 2000-ACCRUE-INTEREST
           END-EVALUATE

           IF LK-MONTH-END
              AND NOT ACCT-CLOSED
               PERFORM 3000-CAPITALISE-INTEREST
           END-IF

           IF NOT ACCT-CLOSED
               WRITE ACCT-OUT-REC FROM ACCT-REC
               ADD 1 TO WS-WRITTEN-CNT
           END-IF

           PERFORM 8000-READ-ACCOUNT.

      *----------------------------------------------------------------*
       2000-ACCRUE-INTEREST.
           PERFORM 2100-DETERMINE-TIER

           IF ACCT-TYPE-BONUS-SAVER
              AND ACCT-BONUS-ELIGIBLE
              AND ACCT-WITHDRAWALS-MTD = ZERO
               ADD RT-BONUS-RATE TO WS-APPLIED-RATE
           END-IF

           COMPUTE WS-DAILY-INT =
               ACCT-BALANCE * WS-APPLIED-RATE / 100 / WS-DAYS-IN-YEAR

           ADD WS-DAILY-INT TO ACCT-ACCRUED-INT
               ON SIZE ERROR
                   MOVE 'ACCRUED INTEREST OVERFLOW - DAY NOT ADDED'
                     TO WS-EXC-MESSAGE
                   PERFORM 7000-WRITE-EXCEPTION
           END-ADD

           ADD 1 TO WS-ACCRUED-CNT.

      *----------------------------------------------------------------*
       2100-DETERMINE-TIER.
           IF ACCT-DORMANT
               MOVE RT-TIER-RATE (1) TO WS-APPLIED-RATE
           ELSE
               SET TIER-NOT-FOUND TO TRUE
               PERFORM VARYING WS-TIER-IDX FROM RT-TIER-COUNT BY -1
                   UNTIL TIER-FOUND
                      OR WS-TIER-IDX < 1
                   IF ACCT-BALANCE >= RT-TIER-FLOOR (WS-TIER-IDX)
                       MOVE RT-TIER-RATE (WS-TIER-IDX)
                         TO WS-APPLIED-RATE
                       SET TIER-FOUND TO TRUE
                   END-IF
               END-PERFORM
           END-IF.

      *----------------------------------------------------------------*
       3000-CAPITALISE-INTEREST.
           COMPUTE ACCT-BALANCE ROUNDED =
               ACCT-BALANCE + ACCT-ACCRUED-INT
               ON SIZE ERROR
                   MOVE 'BALANCE OVERFLOW - INTEREST NOT CAPITALISED'
                     TO WS-EXC-MESSAGE
                   PERFORM 7000-WRITE-EXCEPTION
               NOT ON SIZE ERROR
                   ADD 1 TO WS-CAPITALISED-CNT END-ADD
           END-COMPUTE

           MOVE ZERO        TO ACCT-ACCRUED-INT
           MOVE LK-RUN-DATE TO ACCT-LAST-INT-DATE
           MOVE ZERO        TO ACCT-WITHDRAWALS-MTD.

      *----------------------------------------------------------------*
       7000-WRITE-EXCEPTION.
           MOVE ACCT-NUMBER TO WS-EXC-ACCT-NUMBER
           WRITE EXCPTN-REC FROM WS-EXCEPTION-LINE
           ADD 1 TO WS-EXCEPTION-CNT.

      *----------------------------------------------------------------*
       8000-READ-ACCOUNT.
           READ ACCT-IN-FILE
               AT END
                   SET END-OF-ACCOUNTS TO TRUE
               NOT AT END
                   ADD 1 TO WS-READ-CNT
           END-READ.

      *----------------------------------------------------------------*
       9000-TERMINATE.
           DISPLAY 'INTCALC - RUN DATE        : ' LK-RUN-DATE
           DISPLAY 'INTCALC - MONTH END       : ' LK-MONTH-END-SW
           DISPLAY 'INTCALC - RATE TIERS      : ' RT-TIER-COUNT
           DISPLAY 'INTCALC - ACCOUNTS READ   : ' WS-READ-CNT
           DISPLAY 'INTCALC - ACCOUNTS WRITTEN: ' WS-WRITTEN-CNT
           DISPLAY 'INTCALC - INTEREST ACCRUED: ' WS-ACCRUED-CNT
           DISPLAY 'INTCALC - CAPITALISED     : ' WS-CAPITALISED-CNT
           DISPLAY 'INTCALC - EXCEPTIONS      : ' WS-EXCEPTION-CNT
           CLOSE ACCT-IN-FILE
                 RATE-FILE
                 ACCT-OUT-FILE
                 EXCEPTION-FILE.
