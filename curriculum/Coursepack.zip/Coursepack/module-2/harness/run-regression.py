"""run-regression: run the original and modified INTCALC on the same input and compare.

Usage:
  python3 harness/run-regression.py [--parm 20261030,N] [--add boundary-records.csv]

  --parm   The EXEC PARM for the run: run date CCYYMMDD, comma, month-end switch.
           D = 20261030,N (default)   M = 20261031,Y   L = 20280229,N
  --add    A CSV of extra records to add to the 5,000-account file before the run.
           If you leave it out, module-2/boundary-records.csv is added automatically
           when it has records. Use --no-add to run the 5,000 accounts alone.

What it does, as the EODINT job would on z/OS:
  1. Compiles INTCALC.cbl (with RATETIER.cpy) and INTCALC-v2.cbl (with RATETIER-v2.cpy).
  2. Builds the rate file for each version from rates-current.csv and rates-new.csv.
  3. Sorts the account file by account number (STEP020).
  4. Runs both versions with the same PARM (STEP030), each writing its own new master.
  5. Compares the two output masters record by record and writes a report.

Expected-change rule used to classify differences (from the change request):
  An account should produce different output when its status is not
  closed (C), frozen (F), legal hold (L) or dormant (D), and its balance
  is 10,000.00 or more. Rates only go up, so its interest should not go down.
  On a month-end run, rounding to the cent can absorb the difference, so an
  in-rule account that is unchanged is accepted.
"""
import argparse, csv, os, shutil, subprocess, sys
from decimal import Decimal
from datetime import datetime

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from acctrec import pack_record, unpack_record, read_records, rate_file, RecordError, FIELDS

MODULE = os.path.dirname(HERE)
WORK = os.path.join(HERE, "work")
REPORTS = os.path.join(MODULE, "reports")
EXE = ".exe" if os.name == "nt" else ""
THRESHOLD = Decimal("10000.00")
EXCLUDED = {"C", "F", "L", "D"}


def compile_version(name, program, copybook_v):
    inc = os.path.join(WORK, f"copy-{name}")
    os.makedirs(inc, exist_ok=True)
    shutil.copy(os.path.join(MODULE, "ACCTREC.cpy"), os.path.join(inc, "ACCTREC.cpy"))
    shutil.copy(os.path.join(MODULE, copybook_v), os.path.join(inc, "RATETIER.cpy"))
    exe = os.path.join(WORK, f"intcalc-{name}{EXE}")
    cmd = ["cobc", "-std=ibm", "-x", "-o", exe, os.path.join(HERE, "PARMDRV.cbl"),
           os.path.join(MODULE, program), "-I", inc]
    # Compile from the private copybook folder: cobc searches the current folder for
    # copybooks first, so running from module-2 would pick up the wrong RATETIER.
    p = subprocess.run(cmd, capture_output=True, text=True, cwd=inc)
    if p.returncode != 0:
        sys.exit(f"Compile of {program} failed:\n{p.stdout}{p.stderr}")
    return exe


def run_version(name, exe, acctin, rates, parm):
    out = os.path.join(WORK, f"ACCTOUT-{name}.dat")
    exc = os.path.join(WORK, f"EXCPTN-{name}.txt")
    env = dict(os.environ, DD_ACCTIN=acctin, DD_RATEIN=rates, DD_ACCTOUT=out, DD_EXCPTN=exc)
    p = subprocess.run([exe, parm], env=env, capture_output=True, text=True)
    if p.returncode != 0:
        sys.exit(f"{name} run ended with return code {p.returncode}:\n{p.stdout}{p.stderr}")
    excs = []
    if os.path.exists(exc):
        data = open(exc, "rb").read()
        excs = [data[i:i + 80].decode().rstrip() for i in range(0, len(data), 80)]
    return out, p.stdout.strip().splitlines(), excs


def fmt(rec):
    if rec is None:
        return "not on output file"
    return (f"bal {rec['ACCT-BALANCE']:>12}  accrued {rec['ACCT-ACCRUED-INT']:>11}  "
            f"date {rec['ACCT-LAST-INT-DATE']}  wd {rec['ACCT-WITHDRAWALS-MTD']}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--parm", default="20261030,N")
    ap.add_argument("--add")
    ap.add_argument("--no-add", action="store_true")
    ap.add_argument("--accounts", default=os.path.join(MODULE, "data", "ACCTIN-5000.dat"))
    a = ap.parse_args()
    default_add = os.path.join(MODULE, "boundary-records.csv")
    if not a.add and not a.no_add and os.path.exists(default_add) \
            and open(default_add).read().strip():
        a.add = default_add
    month_end = a.parm.endswith(",Y")
    os.makedirs(WORK, exist_ok=True)
    os.makedirs(REPORTS, exist_ok=True)

    # Input: the 5,000-account file plus any added records, sorted (STEP020)
    recs = read_records(a.accounts)
    added = 0
    if a.add:
        with open(a.add, newline="") as f:
            rows = list(csv.DictReader(f))
        try:
            recs += [pack_record(r) for r in rows]
        except RecordError as e:
            sys.exit(f"{a.add}: {e}")
        added = len(rows)
    recs.sort(key=lambda r: r[:12])
    acctin = os.path.join(WORK, "ACCTIN-SORTED.dat")
    open(acctin, "wb").write(b"".join(recs))

    def rates(csvname, places, out):
        with open(os.path.join(MODULE, csvname), newline="") as f:
            open(out, "wb").write(rate_file(list(csv.DictReader(f)), places))
        return out
    r_orig = rates("rates-current.csv", 2, os.path.join(WORK, "RATETIER-CURRENT.dat"))
    r_mod = rates("rates-new.csv", 3, os.path.join(WORK, "RATETIER-NEW.dat"))

    exe_o = compile_version("original", "INTCALC.cbl", "RATETIER.cpy")
    exe_m = compile_version("modified", "INTCALC-v2.cbl", "RATETIER-v2.cpy")
    out_o, log_o, exc_o = run_version("original", exe_o, acctin, r_orig, a.parm)
    out_m, log_m, exc_m = run_version("modified", exe_m, acctin, r_mod, a.parm)

    inp = {r[:12].decode().strip(): unpack_record(r) for r in recs}
    o = {r[:12].decode().strip(): unpack_record(r) for r in read_records(out_o)}
    m = {r[:12].decode().strip(): unpack_record(r) for r in read_records(out_m)}

    unchanged = expected = dropped_both = 0
    unexplained = []
    for acct, rec in inp.items():
        ro, rm = o.get(acct), m.get(acct)
        in_rule = rec["ACCT-STATUS"] not in EXCLUDED and rec["ACCT-BALANCE"] is not None \
            and rec["ACCT-BALANCE"] >= THRESHOLD
        if ro is None and rm is None:
            dropped_both += 1
            unchanged += 1
            continue
        if ro is None or rm is None:
            unexplained.append((acct, "On one output file but not the other", rec, ro, rm))
            continue
        same = all(ro[f] == rm[f] for f in FIELDS)
        if same:
            if in_rule and not month_end:
                unexplained.append((acct, "Should change (in the expected-change rule) but is UNCHANGED", rec, ro, rm))
            else:
                unchanged += 1
            continue
        if not in_rule:
            unexplained.append((acct, "CHANGED, but outside the expected-change rule", rec, ro, rm))
            continue
        went_down = (rm["ACCT-ACCRUED-INT"] < ro["ACCT-ACCRUED-INT"] if not month_end
                     else rm["ACCT-BALANCE"] < ro["ACCT-BALANCE"])
        if went_down:
            unexplained.append((acct, "Changed as the rule predicts, but interest went DOWN, not up", rec, ro, rm))
        else:
            expected += 1

    bnd = [k for k in inp if k.startswith("BND")]
    lines = []
    w = lines.append
    w("=" * 78)
    w("INTCALC REGRESSION REPORT   original (INTCALC) vs modified (INTCALC-v2)")
    w("=" * 78)
    w(f"Run PARM         : {a.parm}   ({'month-end run' if month_end else 'daily run'})")
    w(f"Produced         : {datetime.now():%Y-%m-%d %H:%M}")
    w(f"Input records    : {len(recs)}   (5,000-account file + {added} added)")
    w(f"Original rates   : rates-current.csv    Modified rates: rates-new.csv")
    w("")
    w(f"  {unchanged} unchanged, {expected} changed as expected, {len(unexplained)} unexplained")
    w(f"  ({unchanged} unchanged includes {dropped_both} closed accounts dropped by both versions)")
    w("")
    w("Expected-change rule: status not C, F, L or D, and balance >= 10,000.00.")
    w("Rates only go up, so in-rule interest should not go down." +
      (" Month-end: an in-rule account may be unchanged." if month_end else ""))
    w("")
    w("-" * 78)
    w(f"UNEXPLAINED DIFFERENCES ({len(unexplained)})")
    w("-" * 78)
    if not unexplained:
        w("None.")
    for acct, why, rec, ro, rm in unexplained:
        w(f"{acct}  {why}")
        w(f"   input     : type {rec['ACCT-TYPE']} status {rec['ACCT-STATUS']}  bal {rec['ACCT-BALANCE']:>12}  "
          f"accrued {rec['ACCT-ACCRUED-INT']:>11}  bonus {rec['ACCT-BONUS-FLAG']}  wd {rec['ACCT-WITHDRAWALS-MTD']}")
        w(f"   original  : {fmt(ro)}")
        w(f"   modified  : {fmt(rm)}")
        w("")
    if bnd:
        w("-" * 78)
        w(f"YOUR ADDED RECORDS ({len(bnd)})  - compare with the Expected columns in scenarios.md")
        w("-" * 78)
        for acct in sorted(bnd):
            rec, ro, rm = inp[acct], o.get(acct), m.get(acct)
            diff = "no output" if ro is None and rm is None else (
                "SAME" if ro and rm and all(ro[f] == rm[f] for f in FIELDS) else "DIFFERENT")
            w(f"{acct}  status {rec['ACCT-STATUS']} type {rec['ACCT-TYPE']} input bal {rec['ACCT-BALANCE']}  -> {diff}")
            w(f"   original  : {fmt(ro)}")
            w(f"   modified  : {fmt(rm)}")
        w("")
    w("-" * 78)
    w("PROGRAM COUNTS")
    w("-" * 78)
    for name, log in (("original", log_o), ("modified", log_m)):
        w(f"[{name}]")
        lines.extend("   " + x for x in log)
    w("")
    w("EXCEPTIONS WRITTEN (original / modified)")
    w(f"   original: {len(exc_o)}   modified: {len(exc_m)}")
    for x in sorted(set(exc_m) ^ set(exc_o)):
        w(f"   only in {'modified' if x in exc_m else 'original'}: {x}")

    tag = a.parm.replace(",", "-")
    for name in ("original", "modified"):
        src = os.path.join(WORK, f"EXCPTN-{name}.txt")
        if os.path.exists(src):
            data = open(src, "rb").read()
            open(os.path.join(REPORTS, f"exceptions-{name}-{tag}.txt"), "w").write(
                "\n".join(data[i:i + 80].decode().rstrip() for i in range(0, len(data), 80)) + "\n")
    w("")
    w(f"Exception reports saved as reports/exceptions-original-{tag}.txt and exceptions-modified-{tag}.txt")
    report = "\n".join(lines)
    name = os.path.join(REPORTS, f"regression-{a.parm.replace(',', '-')}.txt")
    open(name, "w").write(report + "\n")
    print(report)
    print(f"\nReport saved to {name}")


if __name__ == "__main__":
    main()
