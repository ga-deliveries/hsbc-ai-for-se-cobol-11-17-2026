"""pack-records: turn a CSV of ACCTREC field values into the 100-byte fixed-width file.

Usage:
  python pack-records.py boundary-records.csv boundary-records.dat
      Packs each CSV row (header = ACCTREC field names, readable decimals,
      no FILLER) into one 100-byte record, packing the COMP-3 fields.
  python pack-records.py --hex boundary-records.csv
      Shows each record's ACCT-BALANCE and ACCT-ACCRUED-INT as packed hex,
      so you can check the sign half-byte yourself.
  python pack-records.py --dump some-file.dat
      Unpacks a fixed-width file back to readable CSV on screen.
"""
import csv, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from acctrec import pack_record, unpack_record, read_records, RecordError, FIELDS


def load_csv(path):
    with open(path, newline="") as f:
        rows = list(csv.DictReader(f))
    missing = [c for c in FIELDS if c not in rows[0]] if rows else FIELDS
    if missing:
        sys.exit(f"{path}: missing columns {', '.join(missing)}")
    return rows


def main(argv):
    if len(argv) == 3 and argv[1] == "--hex":
        for i, row in enumerate(load_csv(argv[2]), 1):
            r = pack_record(row)
            print(f"{row['ACCT-NUMBER']:<12}  ACCT-BALANCE {row['ACCT-BALANCE']:>12} = X'{r[15:20].hex().upper()}'"
                  f"   ACCT-ACCRUED-INT {row['ACCT-ACCRUED-INT']:>11} = X'{r[20:25].hex().upper()}'")
        return
    if len(argv) == 3 and argv[1] == "--dump":
        w = csv.writer(sys.stdout)
        w.writerow(FIELDS)
        for r in read_records(argv[2]):
            rec = unpack_record(r)
            w.writerow([rec[f] if rec[f] is not None else "INVALID-PACKED" for f in FIELDS])
        return
    if len(argv) != 3:
        sys.exit(__doc__)
    rows = load_csv(argv[1])
    out, errors = b"", []
    for i, row in enumerate(rows, 2):
        try:
            out += pack_record(row)
        except RecordError as e:
            errors.append(f"line {i}: {e}")
    if errors:
        sys.exit("Not packed. Fix these rows first:\n  " + "\n  ".join(errors))
    open(argv[2], "wb").write(out)
    print(f"Packed {len(rows)} records ({len(out)} bytes) into {argv[2]}")


if __name__ == "__main__":
    main(sys.argv)
