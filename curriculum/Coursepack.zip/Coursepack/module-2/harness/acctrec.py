"""ACCTREC layout and packed-decimal (COMP-3) helpers for the course harness.

The layout matches ACCTREC.cpy exactly: 100-byte fixed-width records.
"""
from decimal import Decimal, ROUND_DOWN

RECLEN = 100

# name, PIC, format, offset (1-based), length, digits, scale
LAYOUT = [
    ("ACCT-NUMBER",          "X(12)",      "text",   1, 12, None, None),
    ("ACCT-TYPE",            "X(02)",      "text",  13,  2, None, None),
    ("ACCT-STATUS",          "X(01)",      "text",  15,  1, None, None),
    ("ACCT-BALANCE",         "S9(7)V99",   "comp3", 16,  5, 9, 2),
    ("ACCT-ACCRUED-INT",     "S9(5)V9(4)", "comp3", 21,  5, 9, 4),
    ("ACCT-LAST-INT-DATE",   "9(08)",      "zoned", 26,  8, 8, 0),
    ("ACCT-BONUS-FLAG",      "X(01)",      "text",  34,  1, None, None),
    ("ACCT-WITHDRAWALS-MTD", "9(03)",      "zoned", 35,  3, 3, 0),
    ("FILLER",               "X(63)",      "text",  38, 63, None, None),
]
FIELDS = [f[0] for f in LAYOUT if f[0] != "FILLER"]


class RecordError(ValueError):
    pass


def pack_comp3(value, digits, scale, field):
    d = Decimal(str(value).strip())
    if "." in str(value) and len(str(value).split(".")[1]) > scale:
        raise RecordError(f"{field}: {value} has more than {scale} decimal places")
    n = int((d * (10 ** scale)).to_integral_value(rounding=ROUND_DOWN))
    if len(str(abs(n))) > digits:
        raise RecordError(f"{field}: {value} does not fit PIC with {digits} digits")
    sign = "D" if n < 0 else "C"
    h = str(abs(n)).rjust(digits, "0") + sign
    if len(h) % 2:
        h = "0" + h
    return bytes.fromhex(h)


def unpack_comp3(b, scale):
    h = b.hex().upper()
    if not h[:-1].isdigit() or h[-1] not in "CDF":
        return None  # invalid packed data (e.g. spaces) - an S0C7 on z/OS
    n = int(h[:-1]) * (-1 if h[-1] == "D" else 1)
    return Decimal(n).scaleb(-scale)


def pack_record(row):
    out = b""
    for name, pic, fmt, off, length, digits, scale in LAYOUT:
        if name == "FILLER":
            out += b" " * length
            continue
        raw = str(row.get(name, "")).strip()
        if fmt == "text":
            if len(raw) > length:
                raise RecordError(f"{name}: '{raw}' is longer than {length} bytes")
            out += raw.ljust(length).encode("ascii")
        elif fmt == "comp3":
            out += pack_comp3(raw or "0", digits, scale, name)
        else:  # zoned, unsigned display numeric
            if not raw.isdigit():
                raise RecordError(f"{name}: '{raw}' is not an unsigned whole number")
            if len(raw) > length:
                raise RecordError(f"{name}: '{raw}' does not fit {pic}")
            out += raw.rjust(length, "0").encode("ascii")
    assert len(out) == RECLEN
    return out


def unpack_record(r):
    rec = {}
    for name, pic, fmt, off, length, digits, scale in LAYOUT:
        if name == "FILLER":
            continue
        b = r[off - 1: off - 1 + length]
        if fmt == "comp3":
            rec[name] = unpack_comp3(b, scale)
        else:
            rec[name] = b.decode("ascii", "replace").rstrip() if fmt == "text" else b.decode("ascii", "replace")
    return rec


def read_records(path):
    data = open(path, "rb").read()
    if len(data) % RECLEN:
        raise RecordError(f"{path}: length {len(data)} is not a multiple of {RECLEN}")
    return [data[i:i + RECLEN] for i in range(0, len(data), RECLEN)]


def rate_file(csv_rows, rate_digits_after_point):
    """Build the 80-byte RATEIN records: floor 9(05), rate 9(02)V99 or 9(02)V999, filler."""
    out = b""
    for row in csv_rows:
        floor = int(Decimal(row["FLOOR"]))
        rate = Decimal(row["RATE-PCT"])
        n = int((rate * (10 ** rate_digits_after_point)).to_integral_value(rounding=ROUND_DOWN))
        out += (str(floor).rjust(5, "0") + str(n).rjust(2 + rate_digits_after_point, "0")).encode().ljust(80)
    return out
