MODULE 2 HARNESS

HOW TO RUN IT 

  VS Code (recommended)
    Open the module-2 folder (File > Open Folder), then
    Terminal > Run Task... and pick one of:
      Run regression: daily run D (20261030,N)       <- the Lab run
      Run regression: month-end run M (20261031,Y)
      Run regression: leap-year run L (20280229,N)
      Run regression: 5,000 accounts only (no boundary records)
      pack-records: show packed hex of boundary-records.csv
    Ctrl+Shift+B runs the daily run D directly.

  Linux terminal (from the module-2 folder)
    harness/run-regression.sh                       daily run D
    harness/run-regression.sh --parm 20261031,Y     month-end run M
    harness/run-regression.sh --parm 20280229,N     leap-year run L
    harness/run-regression.sh --no-add              5,000 accounts only
    harness/pack-records.sh --hex boundary-records.csv

WHAT THE TOOLS DO

pack-records
  Turns a CSV of ACCTREC field values into the 100-byte fixed-width file.
    harness/pack-records.sh boundary-records.csv boundary-records.dat
    harness/pack-records.sh --hex boundary-records.csv     show packed hex of the money fields
    pack-records --dump data/ACCTIN-5000.dat    show a fixed-width file as readable CSV

run-regression
  Runs the original INTCALC and the modified INTCALC-v2 on the same input,
  compares the two new master files record by record, and writes a report.
  Your boundary-records.csv (in the module-2 folder) is added to the 5,000
  accounts automatically, unless you choose "5,000 accounts only" (--no-add).

  Results go to the reports folder:
    regression-<parm>.txt                      the report
    exceptions-original-<parm>.txt             INTCALC's exception file (EXCPTN)
    exceptions-modified-<parm>.txt             INTCALC-v2's exception file

The report's first line is the one to read:
    N unchanged, M changed as expected, X unexplained
Every unexplained difference is listed with its input record and both outputs.
