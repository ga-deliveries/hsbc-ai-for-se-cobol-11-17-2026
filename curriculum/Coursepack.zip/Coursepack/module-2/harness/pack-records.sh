#!/usr/bin/env bash
# Linux launcher. Needs python3 and GnuCOBOL (cobc). Extra arguments are passed through.
cd "$(dirname "$0")"
exec python3 pack-records.py "$@"
