      *================================================================*
      * COPYBOOK : RATETIER                                            *
      * PURPOSE  : SAVINGS INTEREST RATE TIER TABLE (IN STORAGE)       *
      *            LOADED FROM PROD.SAV.RATETIER.CURRENT AT START      *
      * USED BY  : INTCALC, STMTGEN                                    *
      *----------------------------------------------------------------*
      * RATES ARE ANNUAL PERCENTAGES, E.G. 2.27 = 2.27% A YEAR.        *
      * THE BONUS RATE IS ADDED TO THE TIER RATE FOR QUALIFYING        *
      * BONUS SAVER ACCOUNTS. IT IS NOT HELD ON THE RATE FILE.         *
      *----------------------------------------------------------------*
      * CHANGE LOG                                                     *
      * 1994-03-14  RJT  ORIGINAL - 3 TIERS                            *
      * 2004-06-21  DLW  BONUS RATE ADDED FOR BONUS SAVER              *
      * 2009-01-12  KPM  4TH TIER ADDED (50,000 AND OVER)              *
      * 2026-10-29  PVR  CR-48812 RATES TO 3 DECIMAL PLACES            *
      *================================================================*
       01  RATE-TIER-TABLE.
           05  RT-TIER-COUNT            PIC 9(01)       VALUE ZERO.
           05  RT-TIER                  OCCURS 4 TIMES.
               10  RT-TIER-FLOOR        PIC 9(07)V99.
               10  RT-TIER-RATE         PIC 9(02)V999.
           05  RT-BONUS-RATE            PIC 9(02)V999   VALUE 0.500.
